@echo off
rem Lines before chcp are ASCII only. setlocal first: the variable below stays in this run
rem and does not leak into an open console window. No search of the current folder for programs.
setlocal EnableExtensions DisableDelayedExpansion
set "NoDefaultCurrentDirectoryInExePath=1"
set "ODL_CP="
set "ODL_DIR=%~dp0"
goto :odl_start
:anchor
rem Trust anchor: the folder of this very cmd.exe (dynamic variable __APPDIR__), not SystemRoot
rem from the environment. A real variable with the same name hides the dynamic one: clear it.
set "__APPDIR__="
set "ODL_APP=%__APPDIR__%"
if not defined ODL_APP exit /b 1
set "ODL_SYS="
if /i "%ODL_APP:~-10%"=="\System32\" set "ODL_SYS=%ODL_APP:~0,-1%"
if not defined ODL_SYS exit /b 1
set "ODL_WIN=%ODL_SYS:~0,-9%"
if not "%ODL_WIN:~1,2%"==":\" exit /b 1
rem SystemRoot from the environment must match the anchor. Compared with delayed expansion,
rem so quotes and & in a forged value are not parsed as commands.
set "ODL_SRT=1"
setlocal EnableDelayedExpansion
if defined SystemRoot if /i not "!SystemRoot!"=="!ODL_WIN!" set "ODL_SRT="
endlocal & set "ODL_SRT=%ODL_SRT%"
if not defined ODL_SRT exit /b 1
set "SystemRoot=%ODL_WIN%"
set "windir=%ODL_WIN%"
set "SystemDrive=%ODL_WIN:~0,2%"
set "ComSpec=%ODL_SYS%\cmd.exe"
set "PATHEXT=.COM;.EXE;.BAT;.CMD"
set "PATH=%ODL_SYS%;%ODL_WIN%;%ODL_SYS%\Wbem;%ODL_SYS%\WindowsPowerShell\v1.0"
set "PSModulePath=%ODL_SYS%\WindowsPowerShell\v1.0\Modules"
set "NoDefaultCurrentDirectoryInExePath=1"
exit /b 0
:odl_start
call :anchor || goto :fail_sys
cd /d "%ODL_SYS%"
for %%v in (PSModuleAnalysisCachePath SSL_CERT_FILE SSL_CERT_DIR SSLKEYLOGFILE OPENSSL_CONF OPENSSL_ENGINES OPENSSL_MODULES HTTP_PROXY HTTPS_PROXY ALL_PROXY NO_PROXY) do set "%%v="
for /f "delims==" %%v in ('set ^| "%ODL_SYS%\findstr.exe" /b /i /l "COR_ CORECLR_ COMPlus_ DOTNET_"') do set "%%v="
rem One pass, one child cmd.exe: ComSpec is intact while it runs. findstr keeps only lines that
rem start with a prefix, so a forged value with a line break (COR_X=1, then ComSpec=1) does not
rem clear ComSpec or PATH. A forged line that starts with a prefix still can, so the anchor is
rem computed and checked again.
call :anchor || goto :fail_sys
if not defined ODL_DIR goto :fail_sys
cd /d "%ODL_SYS%"
rem The code page of the console is restored at the end (the window may stay open).
for /f "tokens=2 delims=:" %%c in ('"%ODL_SYS%\chcp.com"') do set "ODL_CP=%%c"
"%ODL_SYS%\chcp.com" 65001 >nul
rem Агент Честного знака («Жёлтый мост»): запуск без установленного Python.
rem Ключи в командной строке передаются в agent.py как есть (--setup, --certs,
rem --sign-now, --disconnect, --once).
rem
rem Опора - папка System32 того cmd.exe, который исполняет этот файл (__APPDIR__), а не
rem SystemRoot из окружения: SystemRoot, windir, ComSpec, PATHEXT, PATH (только системные папки)
rem и PSModulePath задаются от нее, переменные профилировщика .NET (COR_*, CORECLR_*, COMPlus_*,
rem DOTNET_*), кэш модулей PowerShell, SSL_CERT_*, OPENSSL_* и прокси из окружения очищаются.
rem Очистка по префиксу идет через for /f, а он запускает cmd.exe по ComSpec: поэтому сначала
rem опора и ComSpec, затем очистка, затем опора еще раз (очистка могла стереть и ее). Внешние программы
rem запускаются только по абсолютным путям из этой папки (chcp.com, powershell.exe, subst.exe),
rem текущая папка во время проверок - System32. Команда where, поиск по PATH и в текущей
rem папке не используются: подложенные python.exe и py.exe не запускаются.
set "ODL_PS=%ODL_SYS%\WindowsPowerShell\v1.0\powershell.exe"
rem Проверка прав и выбор Python - тот же текст, что ACL_PS в agent.py: Base64 от UTF-8 в двух
rem переменных (строка cmd не длиннее 8191 знака), PowerShell получает короткий загрузчик
rem через -EncodedCommand. Тест сверяет, что тексты совпадают.
set "ODL_ACL_S1=JEVycm9yQWN0aW9uUHJlZmVyZW5jZT0nU3RvcCcKJGJhZD1bQ29sbGVjdGlvbnMuQXJyYXlMaXN0XTo6bmV3KCkKJG5vdGU9W0NvbGxlY3Rpb25zLkFycmF5TGlzdF06Om5ldygpCmZ1bmN0aW9uIE9kbE8oJHMpe1tDb25zb2xlXTo6T3V0LldyaXRlTGluZSgkcyl9CmZ1bmN0aW9uIE9kbEIoJHcpe1t2b2lkXSRiYWQuQWRkKCR3KX0KZnVuY3Rpb24gT2RsU2FuKCRzKXskcyAtcmVwbGFjZSAnW15BLVphLXowLTkgLjo7PV8qL1xcLV0nLCdfJ30KZnVuY3Rpb24gT2RsUmF3KCRpKXtpZihbSU8uRGlyZWN0b3J5XTo6RXhpc3RzKCRpKSl7JHM9W0lPLkRpcmVjdG9yeV06OkdldEFjY2Vzc0NvbnRyb2woJGkpfWVsc2V7JHM9W0lPLkZpbGVdOjpHZXRBY2Nlc3NDb250cm9sKCRpKX07W1NlY3VyaXR5LkFjY2Vzc0NvbnRyb2wuUmF3U2VjdXJpdHlEZXNjcmlwdG9yXTo6bmV3KCRzLkdldFNlY3VyaXR5RGVzY3JpcHRvckJpbmFyeUZvcm0oKSwwKX0KZnVuY3Rpb24gT2RsS2lkcygkaSl7QChbSU8uRGlyZWN0b3J5SW5mb106Om5ldygkaSkuR2V0RmlsZVN5c3RlbUluZm9zKCkpfQpmdW5jdGlvbiBPZGxOYXR7CiR0PVtBcHBEb21haW5dOjpDdXJyZW50RG9tYWluLkRlZmluZUR5bmFtaWNBc3NlbWJseShbUmVmbGVjdGlvbi5Bc3NlbWJseU5hbWVdOjpuZXcoJ09kbE5hdCcpLCdSdW4nKS5EZWZpbmVEeW5hbWljTW9kdWxlKCdPZGxOYXQnKS5EZWZpbmVUeXBlKCdPZGxOYXQnLCdQdWJsaWMsQ2xhc3MnKQpmb3JlYWNoKCRxIGluIEAoQCgnRmluZEZpcnN0RmlsZVcnLFtJbnRQdHJdLEAoW3N0cmluZ10sW2J5dGVbXV0pKSxAKCdGaW5kQ2xvc2UnLFtib29sXSxAKFtJbnRQdHJdKSksQCgnR2V0Vm9sdW1lTmFtZUZvclZvbHVtZU1vdW50UG9pbnRXJyxbYm9vbF0sQChbc3RyaW5nXSxbYnl0ZVtdXSxbaW50XSkpKSl7CiR0LkRlZmluZVBJbnZva2VNZXRob2QoJHFbMF0sJ2tlcm5lbDMyLmRsbCcsJ1B1YmxpYyxTdGF0aWMsUGludm9rZUltcGwnLCdTdGFuZGFyZCcsJHFbMV0sW1R5cGVbXV0oJHFbMl0pLCdXaW5hcGknLCdVbmljb2RlJykuU2V0SW1wbGVtZW50YXRpb25GbGFncygnUHJlc2VydmVTaWcnKQp9CiR0LkNyZWF0ZVR5cGUoKQp9CmZ1bmN0aW9uIE9kbFRhZygkaSl7CiRiPVtieXRlW11dOjpuZXcoNjAwKQokaD0kTjo6RmluZEZpcnN0RmlsZVcoJGksJGIpCmlmKCRoLlRvSW50NjQoKSAtZXEgLTEpe3JldHVybiAtMX0KW3ZvaWRdJE46OkZpbmRDbG9zZSgkaCkKaWYoW0JpdENvbnZlcnRlcl06OlRvVUludDMyKCRiLDApIC1iYW5kIDB4NDAwKXtbQml0Q29udmVydGVyXTo6VG9VSW50MzIoJGIsMzYpfWVsc2V7MH0KfQpmdW5jdGlvbiBPZGxWb2woJGkpeyROOjpHZXRWb2x1bWVOYW1lRm9yVm9sdW1lTW91bnRQb2ludFcoJGkrJ1wnLFtieXRlW11dOjpuZXcoMjAwKSwxMDApfQpmdW5jdGlvbiBPZGxSUCgkYyl7KCRjLkF0dHJpYnV0ZXMgLWJhbmQgW0lPLkZpbGVBdHRyaWJ1dGVzXTo6UmVwYXJzZVBvaW50KSAtYW5kIC1ub3QgKCgkYyAtaXMgW0lPLkZpbGVJbmZvXSkgLWFuZCAoT2RsVGFnICRjLkZ1bGxOYW1lKSAtZXEgMjE0NzQ4MzY2Nyl9CmZ1bmN0aW9uIE9kbE93bigkaSwkbil7CiRyPU9kbFJhdyAkaQppZigkci5Pd25lci5WYWx1ZSAtbmUgJG1lKXtPZGxCICgkbisnIG93bmVyPScrJHIuT3duZXIuVmFsdWUpfQppZigtbm90IChbaW50XSRyLkNvbnRyb2xGbGFncyAtYmFuZCBbaW50XVtTZWN1cml0eS5BY2Nlc3NDb250cm9sLkNvbnRyb2xGbGFnc106OkRpc2NyZXRpb25hcnlBY2xQcm90ZWN0ZWQpKXtPZGxCICgkbisnIGluaGVyaXRhbmNlJyl9CiRkPSRyLkRpc2NyZXRpb25hcnlBY2wKaWYoJG51bGwgLWVxICRkKXtPZGxCICgkbisnIG51bGwtZGFjbCcpO3JldHVybn0KJGs9MApmb3JlYWNoKCRhIGluICRkKXsKaWYoKCRhIC1pcyBbU2VjdXJpdHkuQWNjZXNzQ29udHJvbC5Db21tb25BY2VdKSAtYW5kIC1ub3QgJGEuSXNDYWxsYmFjayAtYW5kICRhLkFjZVF1YWxpZmllciAtZXEgJ0FjY2Vzc0FsbG93ZWQnIC1hbmQgLW5vdCAkYS5Jc0luaGVyaXRlZCAtYW5kICRhLlNlY3VyaXR5SWRlbnRpZmllci5WYWx1ZSAtZXEgJG1lKXskaysrfQplbHNlaWYoJGEgLWlzIFtTZWN1cml0eS5BY2Nlc3NDb250cm9sLktub3duQWNlXSl7T2RsQiAoJG4rJyBhY2U9Jytbc3RyaW5nXSRhLkFjZVR5cGUrJzonKyRhLlNlY3VyaXR5SWRlbnRpZmllci5WYWx1ZSl9CmVsc2V7T2RsQiAoJG4rJyBhY2U9Jytbc3RyaW5nXSRhLkFjZVR5cGUpfQp9CmlmKCRrIC1sdCAxKXtPZGxCICgkbisnIG5vLW93bicpfQp9CmZ1bmN0aW9uIE9kbEZpeCgkaSwkbiwkZGlyKXsKJG89KE9kbFJhdyAkaSkuT3duZXIuVmFsdWUKaWYoJG8gLW5lICRtZSl7T2RsQiAoJG4rJyBvd25lcj0nKyRvKTtyZXR1cm59CmlmKCRkaXIpeyRzPVtTZWN1cml0eS5BY2Nlc3NDb250cm9sLkRpcmVjdG9yeVNlY3VyaXR5XTo6bmV3KCk7JGY9J09JQ0knfWVsc2V7JHM9W1NlY3VyaXR5LkFjY2Vzc0NvbnRyb2wuRmlsZVNlY3VyaXR5XTo6bmV3KCk7JGY9Jyd9CiRzLlNldFNlY3VyaXR5RGVzY3JpcHRvclNkZGxGb3JtKCdEOlAoQTsnKyRmKyc7RkE7OzsnKyRtZSsnKScsW1NlY3VyaXR5LkFjY2Vzc0NvbnRyb2wuQWNjZXNzQ29udHJvbFNlY3Rpb25zXTo6QWNjZXNzKQppZigkZGlyKXtbSU8uRGlyZWN0b3J5XTo6U2V0QWNjZXNzQ29udHJvbCgkaSwkcyl9ZWxzZXtbSU8uRmlsZV06OlNldEFjY2Vzc0NvbnRyb2woJGksJHMpfQpPZGxPd24gJGkgJG4KfQpmdW5jdGlvbiBPZGxXYWxrKCRpLCRuKXsKZm9yZWFjaCgkYyBpbiAoT2RsS2lkcyAkaSkpewokY249JG4rJ1wnKyRjLk5hbWUKJGNkPSRjIC1pcyBbSU8uRGlyZWN0b3J5SW5mb10KaWYoT2RsUlAgJGMpe09kbEIgKCRjbisnIHJlcGFyc2UnKTtjb250aW51ZX0KaWYoJG1vZGUgLWVxICdmaXgnKXtPZGxGaXggJGMuRnVsbE5hbWUgJGNuICRjZH1lbHNle09kbE93biAkYy5GdWxsTmFtZSAkY259CmlmKCRjZCl7T2RsV2FsayAkYy5GdWxsTmFtZSAkY259Cn0KfQpmdW5jdGlvbiBPZGxOb1coJGksJG4pewokcj1PZGxSYXcgJGkKaWYoJHIuT3duZXIuVmFsdWUgLW5lICRtZSl7T2RsQiAoJG4rJyBvd25lcj0nKyRyLk93bmVyLlZhbHVlKX0KJGQ9JHIuRGlzY3JldGlvbmFyeUFjbAppZigkbnVsbCAtZXEgJGQpe09kbEIgKCRuKycgbnVsbC1kYWNsJyk7cmV0dXJufQpmb3JlYWNoKCRhIGluICRkKXsKaWYoW2ludF0kYS5BY2VGbGFncyAtYmFuZCBbaW50XVtTZWN1cml0eS5BY2Nlc3NDb250cm9sLkFjZUZsYWdzXTo6SW5oZXJpdE9ubHkpe2NvbnRpbnVlfQppZigtbm90ICgkYSAtaXMgW1NlY3VyaXR5LkFjY2Vzc0NvbnRyb2wuQ29tbW9uQWNlXSkpe09kbEIgKCRuKycgYWNlPScrW3N0cmluZ10kYS5BY2VUeXBlKTtjb250aW51ZX0KaWYoJGEuQWNlUXVhbGlmaWVyIC1uZSAnQWNjZXNzQWxsb3dlZCcpe2NvbnRpbnVlfQokcz0kYS5TZWN1cml0eUlkZW50aWZpZXIuVmFsdWUKaWYoJHMgLWVxICRtZSAtb3IgJHMgLWVxICdTLTEtNS0xOCcgLW9yICRzIC1lcSAnUy0xLTUtMzItNTQ0JyAtb3IgJHMgLWVxICdTLTEtMy0wJyl7Y29udGludWV9CmlmKCRhLkFjY2Vzc01hc2sgLWJhbmQgMHg1MjBEMDE1Nil7T2RsQiAoJG4rJyB3cml0ZT0nKyRzKX0KfQp9CmZ1bmN0aW9uIE9kbFNjYW4oJGksJG4pewpmb3JlYWNoKCRjIGluIChPZGxLaWRzICRpKSl7CiRjbj0kbisnXCcrJGMuTmFtZQppZihPZGxSUCAkYyl7T2RsQiAoJGNuKycgcmVwYXJzZScpO2NvbnRpbnVlfQpPZGxOb1cgJGMuRnVsbE5hbWUgJGNuCmlmKCRjIC1pcyBbSU8uRGlyZWN0b3J5SW5mb10pe09kbFNjYW4gJGMuRnVsbE5hbWUgJGNufQp9Cn0KZnVuY3Rpb24gT2RsVXAoJGksJG4sJGspewokcj1PZGxSYXcgJGkKaWYoQCgkbWUpKyRzeXMgLW5vdGNvbnRhaW5zICRyLk93bmVyLlZhbHVlKXtPZGxCICgncGFyZW50LW93bmVyPScrJG4rJzonKyRyLk93bmVyLlZhbHVlKX0KJGQ9JHIuRGlzY3JldGlvbmFyeUFjbAppZigkbnVsbCAtZXEgJGQpe09kbEIgKCdwYXJlbnQtbnVsbC1kYWNsPScrJG4pO3JldHVybn0KZm9yZWFjaCgkYSBpbiAkZCl7CmlmKFtpbnRdJGEuQWNlRmxhZ3MgLWJhbmQgW2ludF1bU2VjdXJpdHkuQWNjZXNzQ29udHJvbC5BY2VGbGFnc106OkluaGVyaXRPbmx5KXtjb250aW51ZX0KaWYoLW5vdCAoJGEgLWlzIFtTZWN1cml0eS5BY2Nlc3NDb250cm9sLkNvbW1vbkFjZV0pKXtPZGxCICgncGFyZW50LWFjZT0nKyRuKyc6Jytbc3RyaW5nXSRhLkFjZVR5cGUpO2NvbnRpbnVlfQppZigkYS5BY2VRdWFsaWZpZXIgLW5lICdBY2Nlc3NBbGxvd2VkJyl7Y29udGludWV9CiRzPSRhLlNlY3VyaXR5SWRlbnRpZmllci5WYWx1ZQppZigkcyAtZXEgJG1lIC1vciAkcyAtZXEgJ1MtMS0zLTAnIC1vciAkc3lzIC1jb250YWlucyAkcyl7Y29udGludWV9CmlmKCRhLkFjY2Vzc01hc2sgLWJhbmQgJGspe09kbEIgKCdwYXJlbnQtd3JpdGFibGU9JyskbisnOicrJHMpfQp9Cn0KZnVuY3Rpb24gT2RsUlYoJGssJHYpewokeD0kbG0uT3BlblN1YktleSgkaykKaWYoJG51bGwgLWVxICR4KXtyZXR1cm4gJyd9CiR0PVtzdHJpbmddJHguR2V0VmFsdWUoJHYsJycsW01pY3Jvc29mdC5XaW4zMi5SZWdpc3RyeVZhbHVlT3B0aW9uc106OkRvTm90RXhwYW5kRW52aXJvbm1lbnROYW1lcyk7JHguQ2xvc2UoKQokdD0kdCAtaXJlcGxhY2UgJyVTeXN0ZW1Ecml2ZSUnLCR3ZC5TdWJzdHJpbmcoMCwyKSAtaXJlcGxhY2UgJyVTeXN0ZW1Sb290JScsJHdkCmlmKCR0IC1tYXRjaCAnJScpe3JldHVybiAnJ30KJHQuVHJpbUVuZCgnXCcpCn0KZnVuY3Rpb24gT2RsRVYoJGUsJHQpewokdj1bc3RyaW5nXVtFbnZpcm9ubWVudF06OkdldEVudmlyb25tZW50VmFyaWFibGUoJGUpCmlmKCR2IC1hbmQgJHQgLWFuZCAkdiAtbWF0Y2ggJ15bQS1aYS16XTpcXCcgLWFuZCAkdiAtbm90bWF0Y2ggJ1slXj0hJnw8PiJdJyAtYW5kICR2LlRyaW1FbmQoJ1wnKSAtZXEgJHQpe3JldHVybiAkdHJ1ZX0KaWYoJHYgLW9yICR0KXtbdm9pZF0kbm90ZS5BZGQoJGUrJy1lbnYnKX0KJGZhbHNlCn0KdHJ5ewokcD1bc3RyaW5nXSRlbnY6T0RMX0FDTF9QQVRIOyRtb2RlPVtzdHJpbmddJGVudjpPRExfQUNMX01PREUKJG1lPVtTZWN1cml0eS5QcmluY2lwYWwuV2luZG93c0lkZW50aXR5XTo6R2V0Q3VycmVudCgpLlVzZXIuVmFsdWUKaWYoLW5vdCAkcCAtb3IgLW5vdCAkbWUgLW9yIEAoJ2ZpeCcsJ2NoZWNrJywncm9vdCcsJ3BpY2snKSAtbm90Y29udGFpbnMgJG1vZGUpe09kbE8gJ09ETF9BQ0xfQkFEOm5vLWlucHV0JztbRW52aXJvbm1l"
set "ODL_ACL_S2=bnRdOjpFeGl0KDEpfQppZigkcC5MZW5ndGggLWd0IDMpeyRwPSRwLlRyaW1FbmQoJ1wnKX0KJE49T2RsTmF0CiRzeXM9QCgnUy0xLTUtMTgnLCdTLTEtNS0zMi01NDQnLCdTLTEtNS04MC05NTYwMDg4ODUtMzQxODUyMjY0OS0xODMxMDM4MDQ0LTE4NTMyOTI2MzEtMjI3MTQ3ODQ2NCcpCiR3ZD1bSU8uUGF0aF06OkdldERpcmVjdG9yeU5hbWUoW0Vudmlyb25tZW50XTo6U3lzdGVtRGlyZWN0b3J5KQokbG09W01pY3Jvc29mdC5XaW4zMi5SZWdpc3RyeUtleV06Ok9wZW5CYXNlS2V5KFtNaWNyb3NvZnQuV2luMzIuUmVnaXN0cnlIaXZlXTo6TG9jYWxNYWNoaW5lLFtNaWNyb3NvZnQuV2luMzIuUmVnaXN0cnlWaWV3XTo6UmVnaXN0cnk2NCkKJHByPU9kbFJWICgnU09GVFdBUkVcTWljcm9zb2Z0XFdpbmRvd3MgTlRcQ3VycmVudFZlcnNpb25cUHJvZmlsZUxpc3RcJyskbWUpICdQcm9maWxlSW1hZ2VQYXRoJwppZigkbW9kZSAtZXEgJ3Jvb3QnKXsKaWYoKFtTZWN1cml0eS5QcmluY2lwYWwuV2luZG93c1ByaW5jaXBhbF06Om5ldyhbU2VjdXJpdHkuUHJpbmNpcGFsLldpbmRvd3NJZGVudGl0eV06OkdldEN1cnJlbnQoKSkpLklzSW5Sb2xlKFtTZWN1cml0eS5QcmluY2lwYWwuV2luZG93c0J1aWx0SW5Sb2xlXTo6QWRtaW5pc3RyYXRvcikpe09kbEIgJ2VsZXZhdGVkJ30KaWYoJHAgLW5vdG1hdGNoICdeW0EtWmEtel06XFwnIC1vciAkcCAtbWF0Y2ggJ1slXj0hJnw8PiJdJyl7T2RsQiAncGF0aC1jaGFycyd9CmVsc2V7CmlmKFtJTy5Ecml2ZUluZm9dOjpuZXcoJHAuU3Vic3RyaW5nKDAsMSkpLkRyaXZlVHlwZSAtbmUgW0lPLkRyaXZlVHlwZV06OkZpeGVkKXtPZGxCICdkcml2ZS1ub3QtZml4ZWQnfQokeD1bSU8uRGlyZWN0b3J5SW5mb106Om5ldygkcCk7JGM9JG51bGwKd2hpbGUoJG51bGwgLW5lICR4KXsKJGY9JHguRnVsbE5hbWUKaWYoKCR4LkF0dHJpYnV0ZXMgLWJhbmQgW0lPLkZpbGVBdHRyaWJ1dGVzXTo6UmVwYXJzZVBvaW50KSAtYW5kIC1ub3QgKChPZGxUYWcgJGYpIC1lcSAyNjg0MzU0NTYzIC1hbmQgJHByIC1hbmQgJGYgLWVxICRwciAtYW5kIChPZGxWb2wgJGYpKSl7T2RsQiAoJ3JlcGFyc2UtaW4tcGF0aD0nKyR4Lk5hbWUpfQppZigkbnVsbCAtbmUgJGMpe2lmKCRudWxsIC1lcSAkeC5QYXJlbnQpe09kbFVwICRmICRmIDB4MTAwQzAwNDB9ZWxzZXtPZGxVcCAkZiAkeC5OYW1lIDB4NTAwRDAwNDR9fQokYz0keDskeD0keC5QYXJlbnQKfQpPZGxOb1cgJHAgJ2FnZW50LWZvbGRlcicKZm9yZWFjaCgkYyBpbiAoT2RsS2lkcyAkcCkpe2lmKEAoJ2NvbmZpZycsJ2xvZ3MnLCdydW50aW1lJykgLW5vdGNvbnRhaW5zICRjLk5hbWUpe2lmKE9kbFJQICRjKXtPZGxCICgkYy5OYW1lKycgcmVwYXJzZScpO2NvbnRpbnVlfTtPZGxOb1cgJGMuRnVsbE5hbWUgJGMuTmFtZTtpZigkYyAtaXMgW0lPLkRpcmVjdG9yeUluZm9dKXtPZGxTY2FuICRjLkZ1bGxOYW1lICRjLk5hbWV9fX0KZm9yZWFjaCgkeCBpbiAncHl2ZW52LmNmZycsJ3J1bnRpbWVccHl2ZW52LmNmZycpeyRmPVtJTy5QYXRoXTo6Q29tYmluZSgkcCwkeCk7aWYoW0lPLkZpbGVdOjpFeGlzdHMoJGYpIC1vciBbSU8uRGlyZWN0b3J5XTo6RXhpc3RzKCRmKSl7T2RsQiAoJHgrJyBwcmVzZW50Jyl9fQp9Cn1lbHNlaWYoJG1vZGUgLWVxICdwaWNrJyl7CiRhcm09KE9kbFJWICdTWVNURU1cQ3VycmVudENvbnRyb2xTZXRcQ29udHJvbFxTZXNzaW9uIE1hbmFnZXJcRW52aXJvbm1lbnQnICdQUk9DRVNTT1JfQVJDSElURUNUVVJFJykgLWVxICdBUk02NCcKJGN2PSdTT0ZUV0FSRVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvbicKJHBmPU9kbFJWICRjdiAnUHJvZ3JhbUZpbGVzRGlyJzskcDg2PU9kbFJWICRjdiAnUHJvZ3JhbUZpbGVzRGlyICh4ODYpJwokcHk9J15QeXRob24zKFxkKykoLTMyfC1hcm02NCk/JCcKJEw9W0NvbGxlY3Rpb25zLkFycmF5TGlzdF06Om5ldygpOyRvdXQ9W0NvbGxlY3Rpb25zLkFycmF5TGlzdF06Om5ldygpCmlmKE9kbEVWICdVU0VSUFJPRklMRScgJHByKXtbdm9pZF0kTC5BZGQoQCgnVTEnLCgkcHIrJ1xBcHBEYXRhXExvY2FsXFByb2dyYW1zXFB5dGhvbicpLCRweSkpO1t2b2lkXSRMLkFkZChAKCdVMicsKCRwcisnXEFwcERhdGFcTG9jYWxcUHl0aG9uJyksJ15weXRob25jb3JlLTNcLihcZCspKC02NHwtMzJ8LWFybTY0KT8kJykpfQppZihPZGxFViAnUHJvZ3JhbUZpbGVzJyAkcGYpe1t2b2lkXSRMLkFkZChAKCdQMScsJHBmLCRweSkpfQppZihPZGxFViAnUHJvZ3JhbUZpbGVzKHg4NiknICRwODYpe1t2b2lkXSRMLkFkZChAKCdQMicsJHA4NiwkcHkpKX0KZm9yZWFjaCgkYiBpbiAkTCl7CmlmKC1ub3QgW0lPLkRpcmVjdG9yeV06OkV4aXN0cygkYlsxXSkpe2NvbnRpbnVlfQp0cnl7JGRzPUAoW0lPLkRpcmVjdG9yeUluZm9dOjpuZXcoJGJbMV0pLkdldERpcmVjdG9yaWVzKCkpfWNhdGNoe1t2b2lkXSRub3RlLkFkZCgkYlswXSsnLXVucmVhZGFibGUnKTtjb250aW51ZX0KJGtzPVtDb2xsZWN0aW9ucy5BcnJheUxpc3RdOjpuZXcoKTskbnM9W0NvbGxlY3Rpb25zLkFycmF5TGlzdF06Om5ldygpCmZvcmVhY2goJGQgaW4gJGRzKXsKJG09W3JlZ2V4XTo6TWF0Y2goJGQuTmFtZSwkYlsyXSxbVGV4dC5SZWd1bGFyRXhwcmVzc2lvbnMuUmVnZXhPcHRpb25zXTo6SWdub3JlQ2FzZSkKaWYoLW5vdCAkbS5TdWNjZXNzKXtjb250aW51ZX0KJHY9W2ludF0kbS5Hcm91cHNbMV0uVmFsdWU7JHM9JG0uR3JvdXBzWzJdLlZhbHVlCmlmKCRzIC1lcSAnLWFybTY0JyAtYW5kIC1ub3QgJGFybSl7Y29udGludWV9CiRlPVtJTy5QYXRoXTo6Q29tYmluZSgkZC5GdWxsTmFtZSwncHl0aG9uLmV4ZScpCmlmKCR2IC1sdCAxMCAtb3IgLW5vdCBbSU8uRmlsZV06OkV4aXN0cygkZSkpe2NvbnRpbnVlfQppZigoJGQuQXR0cmlidXRlcyAtYm9yIFtJTy5GaWxlXTo6R2V0QXR0cmlidXRlcygkZSkpIC1iYW5kIFtJTy5GaWxlQXR0cmlidXRlc106OlJlcGFyc2VQb2ludCl7Y29udGludWV9CmlmKCRlLlN0YXJ0c1dpdGgoJHArJ1wnLFtTdHJpbmdDb21wYXJpc29uXTo6T3JkaW5hbElnbm9yZUNhc2UpKXtjb250aW51ZX0KaWYoJHMgLWVxICctMzInKXtbdm9pZF0ka3MuQWRkKCR2KX1lbHNle1t2b2lkXSRrcy5BZGQoMTAwMCskdil9O1t2b2lkXSRucy5BZGQoJGQuTmFtZSkKfQoka2E9JGtzLlRvQXJyYXkoKTskbmE9JG5zLlRvQXJyYXkoKTtbQXJyYXldOjpTb3J0KCRrYSwkbmEpO1tBcnJheV06OlJldmVyc2UoJG5hKQpmb3JlYWNoKCRkIGluICRuYSl7W3ZvaWRdJG91dC5BZGQoJGJbMF0rJzonKyRkKX0KfQppZigkb3V0LkNvdW50IC1ndCAwKXtPZGxPICgnT0RMX0FDTF9QWTonKygkb3V0LkdldFJhbmdlKDAsW01hdGhdOjpNaW4oOCwkb3V0LkNvdW50KSkgLWpvaW4gJzsnKSl9Cn1lbHNlewokZGlyPVtJTy5EaXJlY3RvcnldOjpFeGlzdHMoJHApCmlmKC1ub3QgJGRpciAtYW5kIC1ub3QgW0lPLkZpbGVdOjpFeGlzdHMoJHApKXtPZGxCICdub3QtZm91bmQnfQplbHNlewppZigkZGlyKXskdD1bSU8uRGlyZWN0b3J5SW5mb106Om5ldygkcCl9ZWxzZXskdD1bSU8uRmlsZUluZm9dOjpuZXcoJHApfQppZigkdC5BdHRyaWJ1dGVzIC1iYW5kIFtJTy5GaWxlQXR0cmlidXRlc106OlJlcGFyc2VQb2ludCl7T2RsQiAoJHQuTmFtZSsnIHJlcGFyc2UnKX0KZWxzZXsKaWYoJG1vZGUgLWVxICdmaXgnKXtPZGxOb1cgJHAgJHQuTmFtZTtpZigkZGlyKXtPZGxTY2FuICRwICR0Lk5hbWV9O2lmKCRiYWQuQ291bnQgLWd0IDApeyRiYWQuSW5zZXJ0KDAsJ25vLWZpeCcpfX0KaWYoJGJhZC5Db3VudCAtZXEgMCl7CmlmKCRtb2RlIC1lcSAnZml4Jyl7T2RsRml4ICRwICR0Lk5hbWUgJGRpcn1lbHNle09kbE93biAkcCAkdC5OYW1lfQppZigkZGlyKXtPZGxXYWxrICRwICR0Lk5hbWV9Cn0KfQp9Cn0KaWYoJGJhZC5Db3VudCAtZ3QgMCl7T2RsTyAoJ09ETF9BQ0xfQkFEOicrKE9kbFNhbiAoJGJhZC5HZXRSYW5nZSgwLFtNYXRoXTo6TWluKDEyLCRiYWQuQ291bnQpKSAtam9pbiAnOyAnKSkpO1tFbnZpcm9ubWVudF06OkV4aXQoMSl9CmlmKCRub3RlLkNvdW50IC1ndCAwKXtPZGxPICgnT0RMX0FDTF9OT1RFOicrKE9kbFNhbiAoJG5vdGUgLWpvaW4gJzsgJykpKX0KT2RsTyAnT0RMX0FDTF9PSyc7W0Vudmlyb25tZW50XTo6RXhpdCgwKQp9Y2F0Y2h7JGlpPSRfLkludm9jYXRpb25JbmZvOyRlPSRfLkV4Y2VwdGlvbjskdD0kZS5HZXRUeXBlKCkuRnVsbE5hbWUrJyAweCcrJGUuSFJlc3VsdC5Ub1N0cmluZygnWDgnKQppZigkbnVsbCAtbmUgJGUuSW5uZXJFeGNlcHRpb24peyR0Kz0nIGlubmVyICcrJGUuSW5uZXJFeGNlcHRpb24uR2V0VHlwZSgpLkZ1bGxOYW1lKycgMHgnKyRlLklubmVyRXhjZXB0aW9uLkhSZXN1bHQuVG9TdHJpbmcoJ1g4Jyl9Ck9kbE8gKCdPRExfQUNMX0JBRDplcnJvciAnKyhPZGxTYW4gKCR0KycgJyskZS5NZXNzYWdlKycgYXQgbGluZSAnKyRpaS5TY3JpcHRMaW5lTnVtYmVyKyc6ICcrKFtzdHJpbmddJGlpLkxpbmUpLlRyaW0oKSkpKTtbRW52aXJvbm1lbnRdOjpFeGl0KDEpfQo="
set "ODL_ACL_BOOT=aQBmACgAJABFAHgAZQBjAHUAdABpAG8AbgBDAG8AbgB0AGUAeAB0AC4AUwBlAHMAcwBpAG8AbgBTAHQAYQB0AGUALgBMAGEAbgBnAHUAYQBnAGUATQBvAGQAZQAgAC0AbgBlACAAJwBGAHUAbABsAEwAYQBuAGcAdQBhAGcAZQAnACkAewAnAE8ARABMAF8AQQBDAEwAXwBCAEEARAA6AGwAYQBuAGcAdQBhAGcAZQAtAG0AbwBkAGUALQAnACsAJABFAHgAZQBjAHUAdABpAG8AbgBDAG8AbgB0AGUAeAB0AC4AUwBlAHMAcwBpAG8AbgBTAHQAYQB0AGUALgBMAGEAbgBnAHUAYQBnAGUATQBvAGQAZQA7AGUAeABpAHQAIAAxAH0AOwAmACAAKABbAHMAYwByAGkAcAB0AGIAbABvAGMAawBdADoAOgBDAHIAZQBhAHQAZQAoAFsAVABlAHgAdAAuAEUAbgBjAG8AZABpAG4AZwBdADoAOgBVAFQARgA4AC4ARwBlAHQAUwB0AHIAaQBuAGcAKABbAEMAbwBuAHYAZQByAHQAXQA6ADoARgByAG8AbQBCAGEAcwBlADYANABTAHQAcgBpAG4AZwAoACQAZQBuAHYAOgBPAEQATABfAEEAQwBMAF8AUwAxACsAJABlAG4AdgA6AE8ARABMAF8AQQBDAEwAXwBTADIAKQApACkAKQA="
title Агент Честного знака (Жёлтый мост)

rem 0. Папка агента: путь на локальном несъемном диске (не сетевом и не subst) без знаков
rem процента и ^ = ! & | < > ", ни она, ни папки выше не точки соединения и не ссылки (кроме
rem точки подключения тома ровно на папке профиля: User Profile Disks, FSLogix); владелец папки
rem и всего в ней, кроме config, logs, runtime (у них шаг 1), - вы, писать туда не может никто,
rem кроме вас (SYSTEM и Администраторы не в счет); папки выше, до корня диска, никто другой не
rem может удалить, переименовать или перенастроить; файла pyvenv.cfg нет. Права здесь только
rem проверяются: run.cmd уже исполняется из этой папки. До этой проверки путь папки не
rem передается через call. Относительные пути после cd /d закрепляют папку только на время
rem работы; между запусками ее защищают права на нее и на папки выше.
if not exist "%ODL_PS%" goto :fail_ps
set "ODL_ACL_PATH=%ODL_DIR%"
set "ODL_ACL_MODE=root"
call :acl_run
if not "%ODL_ACL_STATE%"=="OK" goto :fail_root
set "ODL_DRV=%ODL_DIR:~0,2%"
if exist "%ODL_SYS%\subst.exe" for /f "usebackq tokens=1" %%s in (`""%ODL_SYS%\subst.exe""`) do if /i "%%s"=="%ODL_DRV%\:" goto :fail_subst
"%ODL_SYS%\chcp.com" 65001 >nul
rem Дальше все пути относительные: python.exe и agent.py берутся из текущей папки агента.
cd /d "%ODL_DIR%" || goto :fail_root

rem 1. config, logs, runtime со всем содержимым (config.json, *.tmp, state.json, журналы,
rem runtime\python.exe, библиотеки, ._pth, comtypes, __pycache__). Сначала только проверка:
rem чужой владелец, чужое право на запись или ссылка - отказ без исправления (файлы могли
rem подменить раньше). Затем права каждого объекта переписываются: только вы.
for %%d in (config logs runtime) do if not exist "%%d" mkdir "%%d"
call :protect config || goto :fail_acl
call :protect logs || goto :fail_acl
call :protect runtime || goto :fail_acl

rem 2. Python. Если есть runtime\python.exe (встраиваемый Python, папка проверена в шаге 1),
rem то только он: установленный в системе Python тогда не ищется вовсе. Иначе установленный
rem Python 3.10+ выбирает PowerShell (режим pick) без запуска Python: профиль и Program Files
rem берутся из HKLM, переменные окружения годятся, только если совпадают с ними. Порядок:
rem профиль\AppData\Local\Programs\Python\Python3*, профиль\AppData\Local\Python\pythoncore-3*
rem (Python install manager), Program Files\Python3*, Program Files (x86)\Python3*; в каждой
rem папке 64-разрядный раньше 32-разрядного, из нескольких - сначала новее; сборки -arm64
rem только на ARM64. pick отдает упорядоченный список (код места:имя папки;...), run.cmd
rem проверяет кандидатов по одному и останавливается на первом годном: запускается только
rem проверяемый python.exe, по одному за раз. Сломанный кандидат (например, Python313 без
rem python313.dll после неудачного удаления) не мешает взять следующий. Запускатель py.exe не
rem используется: чтобы назвать путь, он сам запускает выбранный интерпретатор.
set "ODL_PY="
if not exist "runtime\python.exe" goto :py_system
set "ODL_T=.\runtime\python.exe"
call :py_check || goto :fail_runtime_py
set "ODL_PY=%ODL_T%"
goto :py_found
:py_system
set "ODL_ACL_PATH=%ODL_DIR%"
set "ODL_ACL_MODE=pick"
call :acl_run
if not "%ODL_ACL_STATE%"=="OK" goto :fail_pick
if not defined ODL_ACL_PY goto :fail_python
for %%c in (%ODL_ACL_PY%) do if not defined ODL_PY call :py_try %%c
if not defined ODL_PY goto :fail_python
:py_found

echo Python: "%ODL_PY%"
"%ODL_PY%" -I ".\agent.py" %*
set "ODL_RC=%ERRORLEVEL%"
if "%ODL_RC%"=="0" goto :done
echo.
echo Агент завершился с кодом %ODL_RC%. Подробности выше и в logs\agent.log.
pause
:done
call :restore_cp
endlocal & exit /b %ODL_RC%

:restore_cp
rem Only digits: the value comes from chcp, but it is checked anyway.
if not defined ODL_CP exit /b 0
if not defined ODL_SYS exit /b 0
set "ODL_CP=%ODL_CP: =%"
set "ODL_CP=%ODL_CP:.=%"
if not defined ODL_CP exit /b 0
for /f "delims=0123456789" %%x in ("%ODL_CP%x") do if not "%%x"=="x" exit /b 0
"%ODL_SYS%\chcp.com" %ODL_CP% >nul
exit /b 0

rem ---------------------------------------------------------------- права

:protect
rem %1 - имя папки агента (config, logs, runtime). Режим fix: сначала проверка без записи
rem (чужое право на запись, чужой владелец, ссылка - отказ no-fix), затем список прав каждого
rem объекта переписывается целиком (только вы) и перечитывается.
set "ODL_ACL_PATH=%ODL_DIR%%~1"
set "ODL_ACL_MODE=fix"
call :acl_run
if "%ODL_ACL_STATE%"=="OK" exit /b 0
if not "%ODL_ACL_BAD:~0,6%"=="no-fix" goto :protect_bad
echo Папка %~1: менять файлы в ней может кто-то, кроме вас: %ODL_ACL_BAD%
echo Права в таком случае не исправляются: файлы в ней могли подменить раньше.
echo Удалите папку агента целиком, распакуйте архив заново в папку своего профиля
echo ^(например C:\Users\^<имя^>\YellowBridgeAgent^) и пройдите настройку заново ^(README, «Установка»^).
exit /b 1
:protect_bad
echo Папка %~1: остались чужие права, чужой владелец или ссылка: %ODL_ACL_BAD%
exit /b 1

:acl_run
rem Вход: ODL_ACL_PATH и ODL_ACL_MODE в окружении. Выход: ODL_ACL_STATE=OK или ODL_ACL_BAD,
rem для режима pick еще ODL_ACL_PY и ODL_ACL_NOTE. Текст этих строк состоит только из
rem латиницы, цифр и . : ; = _ * / \ - (без знаков cmd).
set "ODL_ACL_STATE="
set "ODL_ACL_BAD="
set "ODL_ACL_PY="
set "ODL_ACL_NOTE="
for /f "usebackq tokens=1,* delims=:" %%a in (`""%ODL_PS%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand %ODL_ACL_BOOT%"`) do (
  if "%%a"=="ODL_ACL_BAD" set "ODL_ACL_BAD=%%b"
  if "%%a"=="ODL_ACL_OK" set "ODL_ACL_STATE=OK"
  if "%%a"=="ODL_ACL_PY" set "ODL_ACL_PY=%%b"
  if "%%a"=="ODL_ACL_NOTE" set "ODL_ACL_NOTE=%%b"
)
rem Child cmd.exe of for /f runs AutoRun from the registry (it may switch the code page).
"%ODL_SYS%\chcp.com" 65001 >nul
if defined ODL_ACL_BAD set "ODL_ACL_STATE="
if not defined ODL_ACL_STATE if not defined ODL_ACL_BAD set "ODL_ACL_BAD=проверка прав не дала ответа: PowerShell не запустился или его остановил антивирус (проверьте карантин и журнал защитника)"
exit /b 0

rem ---------------------------------------------------------------- Python

:py_try
rem %1 - кандидат от режима pick: код места и имя папки (латиница, цифры, точка, дефис).
rem Удачная проверка версии - ODL_PY. Путь собирается здесь, через call передается только имя.
set "ODL_PC=%~1"
set "ODL_PK=%ODL_PC:~0,2%"
set "ODL_PN=%ODL_PC:~3%"
if "%ODL_PK%"=="U1" goto :py_u1
if "%ODL_PK%"=="U2" goto :py_u2
if "%ODL_PK%"=="P1" goto :py_p1
if "%ODL_PK%"=="P2" goto :py_p2
exit /b 1
rem Строки с переменными окружения разбираются только после того, как режим pick сверил
rem их с HKLM и проверил на опасные знаки, и только для своего места.
:py_u1
set "ODL_T=%USERPROFILE%\AppData\Local\Programs\Python\%ODL_PN%\python.exe"
goto :py_sys_check
:py_u2
set "ODL_T=%USERPROFILE%\AppData\Local\Python\%ODL_PN%\python.exe"
goto :py_sys_check
:py_p1
set "ODL_T=%ProgramFiles%\%ODL_PN%\python.exe"
goto :py_sys_check
:py_p2
set "ODL_T=%ProgramFiles(x86)%\%ODL_PN%\python.exe"
:py_sys_check
call :py_check || exit /b 1
set "ODL_PY=%ODL_T%"
exit /b 0

:py_check
rem Проверка версии запускает один выбранный python.exe (ODL_T), путь не передается через call.
"%ODL_T%" -I -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul || exit /b 1
exit /b 0

rem ---------------------------------------------------------------- отказы

:fail_sys
if defined ODL_APP if exist "%ODL_APP%chcp.com" "%ODL_APP%chcp.com" 65001 >nul
echo Не удалось определить системную папку Windows: run.cmd должен исполнять 64-разрядный
echo cmd.exe из папки System32, а переменная окружения SystemRoot должна указывать на папку
echo Windows. Похоже, окружение подменено или run.cmd запущен 32-разрядной программой.
echo Запустите run.cmd двойным щелчком или из обычной командной строки. Запуск отменен.
goto :fail
:fail_ps
echo Не найден штатный PowerShell ^(%ODL_PS%^): без него нельзя проверить права на папки. Запуск отменен.
goto :fail
:fail_root
echo Папку агента нельзя использовать: %ODL_ACL_BAD%
if "%ODL_ACL_BAD:~0,8%"=="elevated" echo run.cmd запущен от имени администратора. Запустите его обычным двойным щелчком, без «Запуск от имени администратора».
if "%ODL_ACL_BAD:~0,13%"=="language-mode" echo PowerShell ограничен политикой организации ^(ConstrainedLanguage^): нужен полный режим PowerShell для агента, обратитесь к администратору.
echo Нужно: путь на локальном диске ^(не сетевом^) без знаков %% ^^ = ! ^& ^| ^< ^> и без точек
echo соединения и ссылок в пути; владелец папки и всех файлов в ней - вы, менять их не может
echo никто, кроме вас ^(SYSTEM и Администраторы не в счет^); папки выше никто, кроме вас, не может
echo удалить, переименовать или перенастроить ^(parent-writable, parent-owner^); файла pyvenv.cfg нет.
echo Если папка лежит на Рабочем столе, в Документах или в OneDrive, перенесите ее, например,
echo в C:\Users\^<имя^>\YellowBridgeAgent: папки OneDrive Windows помечает как ссылки.
echo Почему не корень диска и не Program Files: новая папка в корне диска наследует право
echo «Изменение» для всех пользователей компьютера ^(любой мог бы подменить run.cmd и agent.py^),
echo а в Program Files без прав администратора не может писать сам агент, и владелец файлов там не вы.
echo Подробности в README, раздел «Безопасность». Запуск отменен.
goto :fail
:fail_subst
echo Папка агента лежит на диске, созданном командой subst: настоящий путь к ней другой.
echo Запустите run.cmd по настоящему пути, например C:\Users\^<имя^>\YellowBridgeAgent. Запуск отменен.
goto :fail
:fail_acl
echo Папка агента должна лежать на локальном диске, быть создана под вашей учетной записью
echo ^(вы владелец всех файлов в ней^) и не быть сетевой, например C:\Users\^<имя^>\YellowBridgeAgent.
echo Подробности в README, раздел «Безопасность». Запуск отменен.
goto :fail
:fail_runtime_py
echo В папке runtime есть python.exe, но он не запускается или старше Python 3.10.
echo Установленный в системе Python в этом случае не ищется. Положите в runtime встраиваемый
echo Python 3.12 заново ^(README, раздел «Встраиваемый Python»^). Запуск отменен.
goto :fail
:fail_pick
echo Не удалось проверить установленный Python: %ODL_ACL_BAD%
echo Положите встраиваемый Python 3.12 в папку runtime ^(README, раздел «Установка»^). Запуск отменен.
goto :fail
:fail_python
echo Python не найден: ни runtime\python.exe рядом с агентом, ни установленный в системе
echo Python 3.10+ в папке профиля ^(AppData\Local\Programs\Python, AppData\Local\Python^) или в
echo Program Files, который запускается. Python из PATH, из текущей папки и через запускатель
echo py.exe не берется.
if defined ODL_ACL_NOTE echo Переменные окружения не совпадают с настройками Windows, эти папки не просматривались: %ODL_ACL_NOTE%
echo Положите встраиваемый Python 3.12 в папку runtime ^(README, раздел «Установка»^) или
echo установите Python с python.org. Запуск отменен.
goto :fail

:fail
pause
call :restore_cp
endlocal & exit /b 2
