# -*- coding: utf-8 -*-
"""Агент Честного знака («Жёлтый мост», onecdatalink.ru): продление ключа сессии True API
подписью сертификата организации на компьютере клиента.

Что делает: раз в минуту (или реже, как скажет мост) спрашивает мост, нужна ли подпись;
получив задание, подписывает строку от Честного знака сертификатом организации
(CAdES-BES, присоединенная, те же параметры, что у кнопки «Подписать в кабинете»),
и отдает подпись мосту. Ключ сессии агент никогда не получает и не видит.

Чего не делает: не хранит пароли контейнеров, не скачивает и не запускает код,
не принимает входящих соединений, не работает от администратора.

Файлы рядом: config/config.json (адрес моста, ключи «Маркировка», install_id, секрет
установки), runtime/state.json (последние подписанные запросы), runtime/agent.lock,
logs/agent.log (журнал без секретов).

Зависимости: стандартная библиотека Python 3.12; для подписи через COM CAdESCOM
нужен пакет comtypes (кладется в runtime/, см. README). Если comtypes нет, подпись
и список сертификатов идут через штатный PowerShell с теми же COM-вызовами.

Отступление от плана (раздел 4.3): трея нет, состояние показывается строками в
консольном окне. Трей можно добавить позже, протокол от этого не меняется.
"""
import argparse
import base64
import ctypes
import datetime
import json
import os
import platform
import re
import secrets
import socket
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

AGENT_VERSION = "1.0.0"

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(ЗДЕСЬ, "config")
LOGS_DIR = os.path.join(ЗДЕСЬ, "logs")
RUNTIME_DIR = os.path.join(ЗДЕСЬ, "runtime")
CONFIG = os.path.join(CONFIG_DIR, "config.json")
STATE = os.path.join(RUNTIME_DIR, "state.json")
LOCK = os.path.join(RUNTIME_DIR, "agent.lock")
LOG = os.path.join(LOGS_DIR, "agent.log")
LOG_MAX = 10 * 1024 * 1024
LOG_KEEP = 3

POLL_MIN_SEC = 10            # мост отвечает 429 too_fast чаще раза в 10 с
POLL_DEFAULT_SEC = 60
BACKOFF_MAX_SEC = 600        # отказы сети: пауза с удвоением до 10 минут
BACKOFF_FORBIDDEN_SEC = 600  # после 403/404: 10 минут
REREGISTER_SEC = 24 * 3600   # повторная регистрация раз в сутки: новые ключи из config.json и смена сертификата доходят до моста
KEYS_MAX = 10                # мост принимает в заявке не больше 10 ключей
CERTS_MAX = 30               # и не больше 30 сертификатов (берутся закрепленные в настройках, затем самые долгие)
NO_LINK_WARN_SEC = 1800      # «нет связи с мостом» после 30 минут
SIGN_TIMEOUT_SEC = 60        # окно ПИН-кода ждем минуту, затем pin_required
PIN_SLOW_SEC = 2.5           # вторая тестовая подпись дольше этого: окно пароля, скорее всего, было
DATA_MIN, DATA_MAX = 16, 4000
SIGNATURE_MAX = 250000
HTTP_TIMEOUT = 60
BASE_URL_DEFAULT = "https://api.onecdatalink.ru"   # адрес моста (API), сайт onecdatalink.ru запросы агента не принимает
ALLOW_LOCAL_HTTP = False   # мост только по https
_LOOPBACK = {"127.0.0.1", "::1", "localhost"}

# Константы COM КриптоПро (те же числа, что cadesplugin подставляет в кабинете).
CAPICOM_CURRENT_USER_STORE = 2
CAPICOM_MY_STORE = "My"
CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED = 2
CAPICOM_CERTIFICATE_FIND_SHA1_HASH = 0
CADESCOM_BASE64_TO_BINARY = 1
CADESCOM_CADES_BES = 1

# Коды ошибок подписи, которые понимает мост (report.error_code в pull).
ERR_CERT_NOT_FOUND = "cert_not_found"
ERR_PIN_REQUIRED = "pin_required"
ERR_PLUGIN_MISSING = "plugin_missing"
ERR_CSP = "csp_error"
ERR_NETWORK = "network"

# HRESULT КриптоПро и Windows, по которым можно назвать причину человеку.
_HRESULT_PIN = {0x8010006E, 0x8010006B, 0x80090016, 0x8009000D, 0x800B0109}
_HRESULT_PIN_WORDS = ("cancel", "отмен", "пароль", "password", "pin", "пин")
# 0x800401F3 (CO_E_CLASSSTRING): ProgID CAdESCOM не зарегистрирован вовсе, так отвечает comtypes.
_HRESULT_PLUGIN = {0x80040154, 0x80080005, 0x800401F3}

REASON_RU = {
    "pair_pending": "ожидает подтверждения в кабинете («Входящие», заявка этого компьютера)",
    "pair_replaced": "этот ключ закреплен за другим компьютером; здесь он больше не обслуживается",
    "auth_mode_cabinet": "у ключа выбран вход через кабинет, а не через агент (карточка ключа, источник)",
    "key_inactive": "ключ выключен или не активен в кабинете",
    "key_unknown": "ключ неизвестен мосту: проверьте ключ в config.json",
    "cert_pending": "сертификат сменился, новый ждет подтверждения в кабинете",
    "backoff": "Честный знак отверг подпись, мост держит паузу",
    "rate_limited": "слишком много подписей за час, мост держит паузу",
    "chz_unavailable": "Честный знак сейчас недоступен, мост повторит позже",
    "version_too_old": "эта версия агента устарела: скачайте новую в кабинете (вкладка «Инструкции»)",
    "no_keys": "у этого компьютера нет ни одного ключа «Маркировка» в кабинете",
    "too_fast": "опрос слишком частый, мост просит подождать",
    "inn_missing": "у ключа в кабинете не задан ИНН организации: впишите его в карточке ключа, до этого подпись не нужна",
    "cert_for_inn_missing": "ИНН ключа в кабинете изменен, сертификат подобран по старому: нужна новая заявка (агент перерегистрируется сам)",
}

# ---------------------------------------------------------------- журнал


def журнал(текст: str) -> None:
    """Файл logs/agent.log без секретов: ключи, секрет установки, data, подпись сюда не попадают."""
    try:
        os.makedirs(LOGS_DIR, exist_ok=True)
        if os.path.exists(LOG) and os.path.getsize(LOG) > LOG_MAX:
            for i in range(LOG_KEEP - 1, 0, -1):
                src = LOG + ("" if i == 1 else ".%d" % (i - 1))
                if os.path.exists(src):
                    os.replace(src, LOG + ".%d" % i)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (datetime.datetime.now().isoformat(timespec="seconds"), текст))
    except OSError:
        pass


def сказать(текст: str, в_журнал: bool = True) -> None:
    """Строка состояния в консоль (вместо трея) и, по умолчанию, в журнал."""
    try:
        print("%s  %s" % (datetime.datetime.now().strftime("%H:%M:%S"), текст), flush=True)
    except (OSError, UnicodeEncodeError):
        pass
    if в_журнал:
        журнал(текст)


def хвост(token: str) -> str:
    t = (token or "").strip()
    return ("..." + t[-8:]) if len(t) > 8 else ("..." + t if t else "")


def хвост_отпечатка(thumb: str) -> str:
    t = (thumb or "").strip().upper()
    return ("..." + t[-8:]) if t else ""


# ---------------------------------------------------------------- настройки


class ОшибкаНастроек(Exception):
    pass


def _норм_отпечаток(t) -> str:
    t = "".join(ch for ch in str(t or "").strip().upper() if ch not in " :")
    if not t:
        return ""
    if len(t) != 40 or any(ch not in "0123456789ABCDEF" for ch in t):
        raise ОшибкаНастроек("отпечаток сертификата должен быть 40 шестнадцатеричных знаков: %s" % хвост_отпечатка(t))
    return t


def разобрать_ключи(значение) -> list:
    """Ключи «Маркировка» из настроек: список строк, список {token, thumbprint}, или строка
    через точку с запятой (одна организация = один ключ). Отпечаток у ключа необязателен:
    без него мост подбирает сертификат по ИНН организации ключа."""
    if значение is None:
        return []
    if isinstance(значение, str):
        значение = [s for s in значение.replace("\n", ";").split(";")]
    if not isinstance(значение, list):
        raise ОшибкаНастроек("keys: ожидается список ключей или строка через точку с запятой")
    ключи, видели = [], set()
    for эл in значение:
        if isinstance(эл, str):
            эл = {"token": эл}
        if not isinstance(эл, dict):
            raise ОшибкаНастроек("keys: каждый ключ - строка или объект {token, thumbprint}")
        token = str(эл.get("token") or эл.get("key") or "").strip()
        if not token:
            continue
        if "ВСТАВЬТЕ" in token.upper():
            raise ОшибкаНастроек("keys: вместо текста-заглушки %s впишите ключ «Маркировка» из кабинета" % token[:24])
        if any(ch.isspace() for ch in token) or len(token) < 16:
            raise ОшибкаНастроек("keys: ключ %s не похож на ключ «Маркировка»" % хвост(token))
        if token in видели:
            continue
        видели.add(token)
        ключи.append({"token": token, "thumbprint": _норм_отпечаток(эл.get("thumbprint"))})
    if len(ключи) > KEYS_MAX:
        raise ОшибкаНастроек("keys: мост принимает не больше %d ключей «Маркировка» на один компьютер, в настройках %d; "
                             "лишние вынесите на другой компьютер" % (KEYS_MAX, len(ключи)))
    return ключи


def адрес_допустим(url: str) -> bool:
    try:
        u = urllib.parse.urlsplit(url)
    except ValueError:
        return False
    if u.scheme == "https" and u.hostname:
        return True
    return bool(ALLOW_LOCAL_HTTP and u.scheme == "http" and (u.hostname or "") in _LOOPBACK)


def разобрать_настройки(текст: str) -> dict:
    """Строгий разбор config.json: адрес моста (только https), ключи, при желании install_id,
    секрет установки, отпечатки. Лишние поля не мешают. Ошибка - понятная строка."""
    try:
        raw = json.loads(текст or "{}")
    except ValueError as e:
        raise ОшибкаНастроек("config.json не читается как JSON: %s" % str(e)[:120])
    if not isinstance(raw, dict):
        raise ОшибкаНастроек("config.json: ожидается объект с полями base_url и keys")
    base_url = str(raw.get("base_url") or raw.get("bridge") or BASE_URL_DEFAULT).strip().rstrip("/")
    if not адрес_допустим(base_url):
        raise ОшибкаНастроек("base_url должен начинаться с https:// (сейчас: %s)" % base_url[:60])
    ключи = разобрать_ключи(raw.get("keys", raw.get("tokens")))
    install_id = str(raw.get("install_id") or "").strip()
    if install_id and not (install_id.startswith("mka-") and len(install_id) == 20
                           and all(ch in "0123456789abcdef" for ch in install_id[4:])):
        raise ОшибкаНастроек("install_id поврежден: удалите его из config.json, агент выпишет новый")
    cfg = {
        "base_url": base_url,
        "keys": ключи,
        "install_id": install_id,
        "agent_secret": str(raw.get("agent_secret") or "").strip(),
        "pin_prompt_seen": bool(raw.get("pin_prompt_seen", False)),
        "cert_confirmed_at": str(raw.get("cert_confirmed_at") or ""),
    }
    return cfg


def _чит(путь: str) -> dict:
    try:
        with open(путь, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def загрузить_настройки() -> dict:
    if not os.path.exists(CONFIG):
        raise ОшибкаНастроек("нет файла config\\config.json: он лежал в архиве, распакуйте архив заново "
                             "и впишите ключ «Маркировка» из кабинета (README, раздел «Установка»)")
    with open(CONFIG, encoding="utf-8-sig") as f:
        cfg = разобрать_настройки(f.read())
    if not cfg["keys"]:
        raise ОшибкаНастроек("в config.json нет ни одного ключа «Маркировка» (поле keys)")
    return cfg


def сохранить_настройки(cfg: dict) -> None:
    """Атомарная запись через временный файл. Старый config.json.tmp удаляется, новый
    создается заново (O_EXCL) и сначала, пока пустой, получает права только себе; если
    защита не удалась, секрет не пишется и config.json не заменяется (ОшибкаНастроек).
    Заранее подложенный tmp с чужим владельцем, чужими правами или открытым чужим
    дескриптором не переиспользуется."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    данные = {
        "base_url": cfg["base_url"],
        "keys": [({"token": k["token"], "thumbprint": k["thumbprint"]} if k.get("thumbprint") else k["token"]) for k in cfg["keys"]],
        "install_id": cfg.get("install_id", ""),
        "agent_secret": cfg.get("agent_secret", ""),
        "pin_prompt_seen": bool(cfg.get("pin_prompt_seen")),
        "cert_confirmed_at": cfg.get("cert_confirmed_at", ""),
    }
    tmp = CONFIG + ".tmp"
    try:
        fd = _новый_tmp(tmp)
    except OSError as e:
        raise ОшибкаНастроек("не удалось создать config\\config.json.tmp заново (%s): настройки не сохранены" % e.__class__.__name__)
    try:
        if not защитить_файл(tmp):
            raise ОшибкаНастроек("не удалось ограничить права на config\\config.json.tmp только вашей учетной записью: "
                                 "настройки с секретом установки не записаны")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            fd = -1
            json.dump(данные, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG)
    except (OSError, ОшибкаНастроек) as e:
        if fd >= 0:
            try:
                os.close(fd)
            except OSError:
                pass
        _убрать(tmp)
        if isinstance(e, ОшибкаНастроек):
            raise
        raise ОшибкаНастроек("config.json не записан (%s)" % e.__class__.__name__)


def _новый_tmp(tmp: str) -> int:
    """Удалить прежний временный файл и создать новый только что (O_EXCL). Не удалось
    удалить (чужой файл, чужой открытый дескриптор) - OSError, запись прерывается."""
    try:
        os.remove(tmp)
    except FileNotFoundError:
        pass
    return os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o600)


def _убрать(путь: str) -> None:
    try:
        os.remove(путь)
    except OSError:
        pass


def состояние_прочитать() -> dict:
    s = _чит(STATE)
    return s if isinstance(s, dict) else {}


def состояние_записать(s: dict) -> None:
    """state.json без секретов. Временный файл тоже создается заново (O_EXCL) в папке
    runtime, права которой при запуске выставлены только себе."""
    tmp = STATE + ".tmp"
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
        fd = _новый_tmp(tmp)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False)
        os.replace(tmp, STATE)
    except OSError:
        _убрать(tmp)


# ---------------------------------------------------------------- защита каталога, замок, права


НА_WINDOWS = os.name == "nt"

# Права на папку агента (PowerShell, Windows PowerShell 5.1). Тот же текст выполняет run.cmd:
# он лежит там в переменных ODL_ACL_S1 и ODL_ACL_S2 (Base64 от UTF-8), а PowerShell получает
# короткий загрузчик ACL_BOOT_PS через -EncodedCommand (тест сверяет, что тексты совпадают).
# Входы - только переменные окружения: ODL_ACL_PATH (путь), ODL_ACL_MODE (режим). SID текущей
# учетной записи скрипт берет сам из своего токена (WindowsIdentity), без whoami.
# Только вызовы .NET и операторы языка, без командлетов (Get-Acl, Get-ChildItem, Join-Path,
# Test-Path, Select-Object, Invoke-Expression): командлеты подгружают модули по PSModulePath,
# а там может лежать папка, в которую пишет кто угодно.
# Режимы:
#   fix   - папка (со всем содержимым) или файл. Сначала проверка без записи: у каждого
#           объекта владелец - вы, ни у кого, кроме вас, SYSTEM и Администраторов, нет прав на
#           запись или смену прав, ссылок нет. Не так - отказ «no-fix» без исправления: файлы
#           могли подменить раньше, и переписанные права это бы скрыли. Затем
#           список прав каждого объекта переписывается целиком: только «вы: полный доступ»,
#           наследование выключено; затем перечитывается сырой DACL.
#   check - проверка без записи: у каждого объекта только ваша запись, как после fix.
#   root  - корень папки агента со всем содержимым, кроме config, logs и runtime (у них своя
#           проверка): run.cmd, agent.py и любые другие файлы и папки. Они уже исполняются или
#           лежат в текущей папке Python, поэтому их права не меняются, а только проверяются:
#           владелец - вы, ни у кого, кроме вас, SYSTEM и Администраторов, нет прав на запись
#           или смену прав, ссылок нет. Путь на локальном несъемном диске (не сетевом) без
#           знаков % ^ = ! & | < > ". Папки выше, до корня диска: владелец - вы, SYSTEM,
#           Администраторы или TrustedInstaller; у других нет права удалить или переименовать
#           папку, сменить ее права или владельца (DELETE, WRITE_DAC, WRITE_OWNER, GENERIC_ALL,
#           GENERIC_WRITE), а также удалять и создавать в ней подпапки (DELETE_CHILD,
#           ADD_SUBDIRECTORY). В корне диска «Прошедшие проверку» по умолчанию могут создавать
#           папки, а удалить или переименовать корень нельзя: там опасны только DELETE_CHILD,
#           WRITE_DAC, WRITE_OWNER и GENERIC_ALL. Иначе папку агента можно было бы подменить
#           переименованием между запусками. Точки повторной
#           обработки в пути различаются по тегу (FindFirstFileW, поле dwReserved0): годится
#           только точка подключения тома (IO_REPARSE_TAG_MOUNT_POINT, ведет на корень тома),
#           стоящая ровно на папке профиля из HKLM ProfileList (User Profile Disks, FSLogix).
#           Точка соединения (junction), символическая ссылка, папки OneDrive и прочее - отказ.
#           Файла pyvenv.cfg нет ни в корне, ни в runtime.
#   pick  - выбор установленного Python без его запуска (для run.cmd): профиль берется из
#           HKLM\...\ProfileList по SID, Program Files из HKLM; переменные USERPROFILE,
#           ProgramFiles, ProgramFiles(x86) годятся, только если совпадают с ними и без
#           опасных знаков. Вывод - упорядоченный список кандидатов
#           ODL_ACL_PY:<U1|U2|P1|P2>:<имя папки>;... (не больше 8; имена только из латиницы,
#           цифр, точки и дефиса): места по очереди, в каждом 64-разрядные раньше 32-разрядных,
#           из нескольких - сначала новее; сборки -arm64 только на ARM64. run.cmd собирает путь
#           сам и проверяет кандидатов по одному до первого годного. Несовпадения - ODL_ACL_NOTE.
# Файлы под дедупликацией Windows Server (тег IO_REPARSE_TAG_DEDUP) внутри папки агента
# ссылками не считаются: это обычные файлы, данные которых хранит сам том.
# P/Invoke (FindFirstFileW, GetVolumeNameForVolumeMountPointW) объявляется через
# Reflection.Emit, без Add-Type: Add-Type запускает компилятор и пишет библиотеку во временную
# папку из окружения.
# Сырой DACL (RawSecurityDescriptor) читается целиком: GetAccessRules() пропускает
# условные (callback) записи. Годится только обычная запись «разрешить» своего SID (не
# условная, не объектная, не унаследованная). Вывод: ODL_ACL_OK или ODL_ACL_BAD:<что не так>
# (только ASCII: имена файлов приходят от чужих, в cmd они не должны стать командой).
ACL_PS = r"""$ErrorActionPreference='Stop'
$bad=[Collections.ArrayList]::new()
$note=[Collections.ArrayList]::new()
function OdlO($s){[Console]::Out.WriteLine($s)}
function OdlB($w){[void]$bad.Add($w)}
function OdlSan($s){$s -replace '[^A-Za-z0-9 .:;=_*/\\-]','_'}
function OdlRaw($i){if([IO.Directory]::Exists($i)){$s=[IO.Directory]::GetAccessControl($i)}else{$s=[IO.File]::GetAccessControl($i)};[Security.AccessControl.RawSecurityDescriptor]::new($s.GetSecurityDescriptorBinaryForm(),0)}
function OdlKids($i){@([IO.DirectoryInfo]::new($i).GetFileSystemInfos())}
function OdlNat{
$t=[AppDomain]::CurrentDomain.DefineDynamicAssembly([Reflection.AssemblyName]::new('OdlNat'),'Run').DefineDynamicModule('OdlNat').DefineType('OdlNat','Public,Class')
foreach($q in @(@('FindFirstFileW',[IntPtr],@([string],[byte[]])),@('FindClose',[bool],@([IntPtr])),@('GetVolumeNameForVolumeMountPointW',[bool],@([string],[byte[]],[int])))){
$t.DefinePInvokeMethod($q[0],'kernel32.dll','Public,Static,PinvokeImpl','Standard',$q[1],[Type[]]($q[2]),'Winapi','Unicode').SetImplementationFlags('PreserveSig')
}
$t.CreateType()
}
function OdlTag($i){
$b=[byte[]]::new(600)
$h=$N::FindFirstFileW($i,$b)
if($h.ToInt64() -eq -1){return -1}
[void]$N::FindClose($h)
if([BitConverter]::ToUInt32($b,0) -band 0x400){[BitConverter]::ToUInt32($b,36)}else{0}
}
function OdlVol($i){$N::GetVolumeNameForVolumeMountPointW($i+'\',[byte[]]::new(200),100)}
function OdlRP($c){($c.Attributes -band [IO.FileAttributes]::ReparsePoint) -and -not (($c -is [IO.FileInfo]) -and (OdlTag $c.FullName) -eq 2147483667)}
function OdlOwn($i,$n){
$r=OdlRaw $i
if($r.Owner.Value -ne $me){OdlB ($n+' owner='+$r.Owner.Value)}
if(-not ([int]$r.ControlFlags -band [int][Security.AccessControl.ControlFlags]::DiscretionaryAclProtected)){OdlB ($n+' inheritance')}
$d=$r.DiscretionaryAcl
if($null -eq $d){OdlB ($n+' null-dacl');return}
$k=0
foreach($a in $d){
if(($a -is [Security.AccessControl.CommonAce]) -and -not $a.IsCallback -and $a.AceQualifier -eq 'AccessAllowed' -and -not $a.IsInherited -and $a.SecurityIdentifier.Value -eq $me){$k++}
elseif($a -is [Security.AccessControl.KnownAce]){OdlB ($n+' ace='+[string]$a.AceType+':'+$a.SecurityIdentifier.Value)}
else{OdlB ($n+' ace='+[string]$a.AceType)}
}
if($k -lt 1){OdlB ($n+' no-own')}
}
function OdlFix($i,$n,$dir){
$o=(OdlRaw $i).Owner.Value
if($o -ne $me){OdlB ($n+' owner='+$o);return}
if($dir){$s=[Security.AccessControl.DirectorySecurity]::new();$f='OICI'}else{$s=[Security.AccessControl.FileSecurity]::new();$f=''}
$s.SetSecurityDescriptorSddlForm('D:P(A;'+$f+';FA;;;'+$me+')',[Security.AccessControl.AccessControlSections]::Access)
if($dir){[IO.Directory]::SetAccessControl($i,$s)}else{[IO.File]::SetAccessControl($i,$s)}
OdlOwn $i $n
}
function OdlWalk($i,$n){
foreach($c in (OdlKids $i)){
$cn=$n+'\'+$c.Name
$cd=$c -is [IO.DirectoryInfo]
if(OdlRP $c){OdlB ($cn+' reparse');continue}
if($mode -eq 'fix'){OdlFix $c.FullName $cn $cd}else{OdlOwn $c.FullName $cn}
if($cd){OdlWalk $c.FullName $cn}
}
}
function OdlNoW($i,$n){
$r=OdlRaw $i
if($r.Owner.Value -ne $me){OdlB ($n+' owner='+$r.Owner.Value)}
$d=$r.DiscretionaryAcl
if($null -eq $d){OdlB ($n+' null-dacl');return}
foreach($a in $d){
if([int]$a.AceFlags -band [int][Security.AccessControl.AceFlags]::InheritOnly){continue}
if(-not ($a -is [Security.AccessControl.CommonAce])){OdlB ($n+' ace='+[string]$a.AceType);continue}
if($a.AceQualifier -ne 'AccessAllowed'){continue}
$s=$a.SecurityIdentifier.Value
if($s -eq $me -or $s -eq 'S-1-5-18' -or $s -eq 'S-1-5-32-544' -or $s -eq 'S-1-3-0'){continue}
if($a.AccessMask -band 0x520D0156){OdlB ($n+' write='+$s)}
}
}
function OdlScan($i,$n){
foreach($c in (OdlKids $i)){
$cn=$n+'\'+$c.Name
if(OdlRP $c){OdlB ($cn+' reparse');continue}
OdlNoW $c.FullName $cn
if($c -is [IO.DirectoryInfo]){OdlScan $c.FullName $cn}
}
}
function OdlUp($i,$n,$k){
$r=OdlRaw $i
if(@($me)+$sys -notcontains $r.Owner.Value){OdlB ('parent-owner='+$n+':'+$r.Owner.Value)}
$d=$r.DiscretionaryAcl
if($null -eq $d){OdlB ('parent-null-dacl='+$n);return}
foreach($a in $d){
if([int]$a.AceFlags -band [int][Security.AccessControl.AceFlags]::InheritOnly){continue}
if(-not ($a -is [Security.AccessControl.CommonAce])){OdlB ('parent-ace='+$n+':'+[string]$a.AceType);continue}
if($a.AceQualifier -ne 'AccessAllowed'){continue}
$s=$a.SecurityIdentifier.Value
if($s -eq $me -or $s -eq 'S-1-3-0' -or $sys -contains $s){continue}
if($a.AccessMask -band $k){OdlB ('parent-writable='+$n+':'+$s)}
}
}
function OdlRV($k,$v){
$x=$lm.OpenSubKey($k)
if($null -eq $x){return ''}
$t=[string]$x.GetValue($v,'',[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);$x.Close()
$t=$t -ireplace '%SystemDrive%',$wd.Substring(0,2) -ireplace '%SystemRoot%',$wd
if($t -match '%'){return ''}
$t.TrimEnd('\')
}
function OdlEV($e,$t){
$v=[string][Environment]::GetEnvironmentVariable($e)
if($v -and $t -and $v -match '^[A-Za-z]:\\' -and $v -notmatch '[%^=!&|<>"]' -and $v.TrimEnd('\') -eq $t){return $true}
if($v -or $t){[void]$note.Add($e+'-env')}
$false
}
try{
$p=[string]$env:ODL_ACL_PATH;$mode=[string]$env:ODL_ACL_MODE
$me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
if(-not $p -or -not $me -or @('fix','check','root','pick') -notcontains $mode){OdlO 'ODL_ACL_BAD:no-input';[Environment]::Exit(1)}
if($p.Length -gt 3){$p=$p.TrimEnd('\')}
$N=OdlNat
$sys=@('S-1-5-18','S-1-5-32-544','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
$wd=[IO.Path]::GetDirectoryName([Environment]::SystemDirectory)
$lm=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
$pr=OdlRV ('SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\'+$me) 'ProfileImagePath'
if($mode -eq 'root'){
if(([Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){OdlB 'elevated'}
if($p -notmatch '^[A-Za-z]:\\' -or $p -match '[%^=!&|<>"]'){OdlB 'path-chars'}
else{
if([IO.DriveInfo]::new($p.Substring(0,1)).DriveType -ne [IO.DriveType]::Fixed){OdlB 'drive-not-fixed'}
$x=[IO.DirectoryInfo]::new($p);$c=$null
while($null -ne $x){
$f=$x.FullName
if(($x.Attributes -band [IO.FileAttributes]::ReparsePoint) -and -not ((OdlTag $f) -eq 2684354563 -and $pr -and $f -eq $pr -and (OdlVol $f))){OdlB ('reparse-in-path='+$x.Name)}
if($null -ne $c){if($null -eq $x.Parent){OdlUp $f $f 0x100C0040}else{OdlUp $f $x.Name 0x500D0044}}
$c=$x;$x=$x.Parent
}
OdlNoW $p 'agent-folder'
foreach($c in (OdlKids $p)){if(@('config','logs','runtime') -notcontains $c.Name){if(OdlRP $c){OdlB ($c.Name+' reparse');continue};OdlNoW $c.FullName $c.Name;if($c -is [IO.DirectoryInfo]){OdlScan $c.FullName $c.Name}}}
foreach($x in 'pyvenv.cfg','runtime\pyvenv.cfg'){$f=[IO.Path]::Combine($p,$x);if([IO.File]::Exists($f) -or [IO.Directory]::Exists($f)){OdlB ($x+' present')}}
}
}elseif($mode -eq 'pick'){
$arm=(OdlRV 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment' 'PROCESSOR_ARCHITECTURE') -eq 'ARM64'
$cv='SOFTWARE\Microsoft\Windows\CurrentVersion'
$pf=OdlRV $cv 'ProgramFilesDir';$p86=OdlRV $cv 'ProgramFilesDir (x86)'
$py='^Python3(\d+)(-32|-arm64)?$'
$L=[Collections.ArrayList]::new();$out=[Collections.ArrayList]::new()
if(OdlEV 'USERPROFILE' $pr){[void]$L.Add(@('U1',($pr+'\AppData\Local\Programs\Python'),$py));[void]$L.Add(@('U2',($pr+'\AppData\Local\Python'),'^pythoncore-3\.(\d+)(-64|-32|-arm64)?$'))}
if(OdlEV 'ProgramFiles' $pf){[void]$L.Add(@('P1',$pf,$py))}
if(OdlEV 'ProgramFiles(x86)' $p86){[void]$L.Add(@('P2',$p86,$py))}
foreach($b in $L){
if(-not [IO.Directory]::Exists($b[1])){continue}
try{$ds=@([IO.DirectoryInfo]::new($b[1]).GetDirectories())}catch{[void]$note.Add($b[0]+'-unreadable');continue}
$ks=[Collections.ArrayList]::new();$ns=[Collections.ArrayList]::new()
foreach($d in $ds){
$m=[regex]::Match($d.Name,$b[2],[Text.RegularExpressions.RegexOptions]::IgnoreCase)
if(-not $m.Success){continue}
$v=[int]$m.Groups[1].Value;$s=$m.Groups[2].Value
if($s -eq '-arm64' -and -not $arm){continue}
$e=[IO.Path]::Combine($d.FullName,'python.exe')
if($v -lt 10 -or -not [IO.File]::Exists($e)){continue}
if(($d.Attributes -bor [IO.File]::GetAttributes($e)) -band [IO.FileAttributes]::ReparsePoint){continue}
if($e.StartsWith($p+'\',[StringComparison]::OrdinalIgnoreCase)){continue}
if($s -eq '-32'){[void]$ks.Add($v)}else{[void]$ks.Add(1000+$v)};[void]$ns.Add($d.Name)
}
$ka=$ks.ToArray();$na=$ns.ToArray();[Array]::Sort($ka,$na);[Array]::Reverse($na)
foreach($d in $na){[void]$out.Add($b[0]+':'+$d)}
}
if($out.Count -gt 0){OdlO ('ODL_ACL_PY:'+($out.GetRange(0,[Math]::Min(8,$out.Count)) -join ';'))}
}else{
$dir=[IO.Directory]::Exists($p)
if(-not $dir -and -not [IO.File]::Exists($p)){OdlB 'not-found'}
else{
if($dir){$t=[IO.DirectoryInfo]::new($p)}else{$t=[IO.FileInfo]::new($p)}
if($t.Attributes -band [IO.FileAttributes]::ReparsePoint){OdlB ($t.Name+' reparse')}
else{
if($mode -eq 'fix'){OdlNoW $p $t.Name;if($dir){OdlScan $p $t.Name};if($bad.Count -gt 0){$bad.Insert(0,'no-fix')}}
if($bad.Count -eq 0){
if($mode -eq 'fix'){OdlFix $p $t.Name $dir}else{OdlOwn $p $t.Name}
if($dir){OdlWalk $p $t.Name}
}
}
}
}
if($bad.Count -gt 0){OdlO ('ODL_ACL_BAD:'+(OdlSan ($bad.GetRange(0,[Math]::Min(12,$bad.Count)) -join '; ')));[Environment]::Exit(1)}
if($note.Count -gt 0){OdlO ('ODL_ACL_NOTE:'+(OdlSan ($note -join '; ')))}
OdlO 'ODL_ACL_OK';[Environment]::Exit(0)
}catch{$ii=$_.InvocationInfo;$e=$_.Exception;$t=$e.GetType().FullName+' 0x'+$e.HResult.ToString('X8')
if($null -ne $e.InnerException){$t+=' inner '+$e.InnerException.GetType().FullName+' 0x'+$e.InnerException.HResult.ToString('X8')}
OdlO ('ODL_ACL_BAD:error '+(OdlSan ($t+' '+$e.Message+' at line '+$ii.ScriptLineNumber+': '+([string]$ii.Line).Trim())));[Environment]::Exit(1)}
"""
# Загрузчик для -EncodedCommand: длинный текст не помещается в строку cmd (8191 знак), поэтому
# он идет через переменные окружения, а в командной строке только этот короткий текст. Без
# Invoke-Expression (это командлет из модуля, см. выше): блок скрипта и оператор вызова &.
# Сначала режим языка: при AppLocker, WDAC или __PSLockdownPolicy PowerShell работает в
# ConstrainedLanguage, где Reflection.Emit и ::new запрещены; без этой строки причина отказа
# терялась бы (в stdout пусто, «проверка прав не дала ответа»). Вывод простой строкой: вызов
# методов [Console] в этом режиме тоже запрещен.
ACL_BOOT_PS = "if($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage'){'ODL_ACL_BAD:language-mode-'+$ExecutionContext.SessionState.LanguageMode;exit 1};& ([scriptblock]::Create([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($env:ODL_ACL_S1+$env:ODL_ACL_S2))))"
ACL_PART = 7000
ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ = {"путь": "", "причина": ""}


def acl_части() -> tuple:
    """ACL_PS в Base64 (UTF-8), две части не длиннее ACL_PART: строки set в run.cmd."""
    b = base64.b64encode(ACL_PS.encode("utf-8")).decode("ascii")
    return b[:ACL_PART], b[ACL_PART:]


def acl_boot_b64() -> str:
    """ACL_BOOT_PS для powershell -EncodedCommand (UTF-16LE, Base64), как в run.cmd."""
    return base64.b64encode(ACL_BOOT_PS.encode("utf-16le")).decode("ascii")


def системная_папка(x86: bool = False) -> str:
    """System32 (x86=True: SysWOW64, если он есть) по GetSystemDirectoryW и
    GetSystemWow64DirectoryW, а не по SystemRoot из окружения: подмененный SystemRoot
    запустил бы чужой powershell.exe. Не Windows - пустая строка."""
    if os.name != "nt":
        return ""
    try:
        k32 = ctypes.windll.kernel32
        buf = ctypes.create_unicode_buffer(600)
        n = k32.GetSystemWow64DirectoryW(buf, 600) if x86 else 0
        if not (0 < n < 600):
            n = k32.GetSystemDirectoryW(buf, 600)
        return buf.value if 0 < n < 600 else ""
    except Exception:  # noqa: BLE001
        return ""


def системная_программа(имя: str) -> str:
    """Абсолютный путь к программе Windows из System32: без поиска в текущей папке, папке
    python.exe и PATH, и без SystemRoot из окружения."""
    import ntpath
    return ntpath.join(системная_папка() or r"C:\Windows\System32", имя)


# Переменные окружения, которые меняют поведение PowerShell и .NET: профилировщик и настройки
# среды .NET грузят чужую библиотеку в powershell.exe, PSModulePath и кэш
# анализа модулей подменяют модули. run.cmd их уже очистил; агент чистит еще раз
# для своих вызовов PowerShell, на случай запуска не через run.cmd.
_PS_ПРЕФИКСЫ_ОКРУЖЕНИЯ = ("COR_", "CORECLR_", "COMPLUS_", "DOTNET_")
_PS_ПЕРЕМЕННЫЕ_ОКРУЖЕНИЯ = {"PSMODULEPATH", "PSMODULEANALYSISCACHEPATH"}


def системный_path(папка: str) -> str:
    """PATH только из системных папок Windows (как в run.cmd): в PATH компьютера бывают папки,
    куда может писать любой пользователь, а недостающие библиотеки Windows ищет в PATH."""
    import ntpath
    win = ntpath.dirname(папка)
    return ";".join((папка, win, ntpath.join(папка, "Wbem"), ntpath.join(папка, "WindowsPowerShell", "v1.0")))


def dll_без_текущей_папки() -> bool:
    """SetDllDirectoryW(""): текущая папка (папка агента, где лежат и чужие для Python файлы)
    больше не участвует в поиске библиотек, которые подгружаются по имени без пути (COM-серверы,
    comtypes). Сама папка агента и так проверена в режиме root целиком; это вторая мера, для
    случая запуска не через run.cmd. Не Windows - ничего не делает."""
    if os.name != "nt":
        return False
    try:
        return bool(ctypes.windll.kernel32.SetDllDirectoryW(""))
    except Exception:  # noqa: BLE001
        return False


def окружение_ps(**доп) -> dict:
    """Окружение для powershell.exe: без COR_*, CORECLR_*, COMPlus_*, DOTNET_*,
    PSModuleAnalysisCachePath; PSModulePath - только системная папка модулей; PATH - только
    системные папки."""
    env = {k: v for k, v in os.environ.items()
           if not k.upper().startswith(_PS_ПРЕФИКСЫ_ОКРУЖЕНИЯ) and k.upper() not in _PS_ПЕРЕМЕННЫЕ_ОКРУЖЕНИЯ
           and k.upper() != "PATH"}
    папка = системная_папка()
    if папка:
        import ntpath
        env["PSModulePath"] = ntpath.join(папка, "WindowsPowerShell", "v1.0", "Modules")
        # Ключи os.environ на Windows в верхнем регистре: SYSTEMROOT и WINDIR убираются, иначе в блоке
        # окружения было бы по две записи на переменную, и какая победит - не определено.
        for k in [k for k in env if k.upper() in ("SYSTEMROOT", "WINDIR")]:
            del env[k]
        env["SystemRoot"] = env["windir"] = ntpath.dirname(папка)
        env["PATH"] = системный_path(папка)
    env.update(доп)
    return env


def разобрать_проверку_acl(вывод: str) -> dict:
    """Строки ODL_ACL_* от ACL_PS -> {"ok", "причина"}. Нет строки ODL_ACL_OK - не годится
    (молчание PowerShell не считается успехом); ODL_ACL_BAD сильнее ODL_ACL_OK."""
    итог = {"ok": False, "причина": ""}
    for строка in (вывод or "").splitlines():
        строка = строка.strip().lstrip("\ufeff")
        if строка.startswith("ODL_ACL_BAD:"):
            итог["причина"] = строка.split(":", 1)[1].strip()[:400] or "unknown"
        elif строка == "ODL_ACL_OK":
            итог["ok"] = True
    if итог["причина"]:
        итог["ok"] = False
    elif not итог["ok"]:
        итог["причина"] = "проверка прав не дала ответа"
    return итог


def хвост_stderr(err, n: int = 200) -> str:
    """Конец stderr PowerShell для журнала: без строк CLIXML, только ASCII без знаков cmd
    (текст ошибки может содержать имена файлов от чужих)."""
    if isinstance(err, bytes):
        err = err.decode("utf-8", "replace")
    строки = [s for s in (err or "").splitlines() if s.strip() and not s.lstrip().startswith(("#< CLIXML", "<Objs"))]
    return re.sub(r"[^A-Za-z0-9 .:;=_*/\\-]", "_", " ".join(" ".join(строки).split()))[-n:]


# Запуск PowerShell агентом: stdin закрыт (Windows PowerShell 5.1 с перенаправленным и не
# закрытым stdin может ждать ввода), -OutputFormat Text - ошибки и прогресс в stderr обычным
# текстом, а не CLIXML (иначе маркеры ODL_* тонут в XML).
_PS_КЛЮЧИ = ["-NoLogo", "-NoProfile", "-NonInteractive", "-OutputFormat", "Text", "-ExecutionPolicy", "Bypass"]


def права_ps(режим: str, путь: str, запуск=None) -> dict:
    """Выполнить ACL_PS в режиме fix, check или root для пути и разобрать результат."""
    запуск = запуск or subprocess.run
    exe = powershell_путь()
    if not exe:
        return {"ok": False, "причина": "штатный PowerShell не найден"}
    s1, s2 = acl_части()
    env = окружение_ps(ODL_ACL_PATH=путь, ODL_ACL_MODE=режим, ODL_ACL_S1=s1, ODL_ACL_S2=s2)
    try:
        r = запуск([exe] + _PS_КЛЮЧИ + ["-EncodedCommand", acl_boot_b64()],
                   stdin=subprocess.DEVNULL, capture_output=True, timeout=300, env=env, cwd=системная_папка() or None)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "причина": "PowerShell не выполнен (%s)" % str(e)[:80]}
    out = r.stdout.decode("utf-8", "replace") if isinstance(r.stdout, bytes) else (r.stdout or "")
    итог = разобрать_проверку_acl(out)
    if not итог["ok"] and итог["причина"] == "проверка прав не дала ответа":
        хвост = хвост_stderr(getattr(r, "stderr", b""))
        итог["причина"] += (" (rc=%s%s; PowerShell мог остановить антивирус или политика организации)"
                            % (r.returncode, (", stderr: " + хвост) if хвост else ""))
    if итог["ok"] and r.returncode != 0:
        итог = {"ok": False, "причина": "PowerShell rc=%s" % r.returncode}
    return итог


def _отказ_прав(путь: str, причина: str) -> bool:
    ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ["путь"], ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ["причина"] = путь, причина
    журнал("права: %s: %s" % (os.path.basename(путь.rstrip("\\/")) or путь, причина))
    return False


def защитить_windows(путь: str, запуск=None) -> bool:
    """Режим fix: папка со всем содержимым или файл получают права только своей учетной
    записи, затем сырой DACL каждого объекта перечитывается. SYSTEM и Администраторы тоже
    считаются чужими (README, раздел «Безопасность»). Отказ - False, причина в журнале и в
    ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ."""
    п = права_ps("fix", путь, запуск)
    if not п["ok"]:
        return _отказ_прав(путь, "после настройки остались чужие права, чужой владелец или ссылка: %s" % п["причина"])
    return True


def проверить_корень(здесь: str = None, запуск=None) -> bool:
    """Режим root: корень папки агента, run.cmd, agent.py (только проверка, без изменений)."""
    здесь = здесь if здесь is not None else ЗДЕСЬ
    п = права_ps("root", здесь, запуск)
    if not п["ok"]:
        return _отказ_прав(здесь, "папку агента, run.cmd или agent.py может менять кто-то, кроме вас: %s" % п["причина"])
    return True


def защитить_файл(путь: str) -> bool:
    """Доступ только текущей учетной записи. Windows: защитить_windows (папка - вместе со
    всем содержимым). Linux: chmod. Отказ - False, вызывающий решает сам."""
    if not НА_WINDOWS:
        try:
            os.chmod(путь, 0o700 if os.path.isdir(путь) else 0o600)
            return True
        except OSError:
            return False
    return защитить_windows(путь)


def интерпретатор_допустим(exe: str = None, здесь: str = None) -> bool:
    """Диагностика, а не защита: ловит только случайно оставленный в папке агента обычный
    python.exe (не runtime\\python.exe). Подмененный интерпретатор эта проверка не
    остановит: она выполняется внутри него, после его собственной загрузки. Защита от
    подмены - выбор Python в run.cmd и закрытые права на папку агента и runtime."""
    exe = exe if exe is not None else sys.executable
    здесь = здесь if здесь is not None else ЗДЕСЬ
    if not exe:
        return False

    def норм(p: str) -> str:
        return os.path.normcase(os.path.realpath(os.path.abspath(p)))

    реальный, корень = норм(exe), норм(здесь)
    if реальный == норм(os.path.join(здесь, "runtime", "python.exe")):
        return True
    return not (реальный == корень or реальный.startswith(корень.rstrip(os.sep) + os.sep))


def защитить_окружение() -> bool:
    """Windows: сначала проверка корня (root), затем config, logs и runtime целиком (fix).
    Linux: chmod папок и известных файлов."""
    for d in (CONFIG_DIR, LOGS_DIR, RUNTIME_DIR):
        os.makedirs(d, exist_ok=True)
    if НА_WINDOWS:
        if not проверить_корень():
            return False
        return all(защитить_файл(d) for d in (CONFIG_DIR, LOGS_DIR, RUNTIME_DIR))
    ок = True
    for p in (CONFIG_DIR, LOGS_DIR, RUNTIME_DIR, CONFIG, STATE, LOCK, LOG):
        if os.path.exists(p) and not защитить_файл(p):
            ок = False
    return ок


_lock_fh = None


def взять_замок() -> bool:
    """Один агент на каталог: два экземпляра подписывали бы одно задание дважды."""
    global _lock_fh
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
        _lock_fh = open(LOCK, "a+")
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(_lock_fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(_lock_fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except OSError:
        if _lock_fh is not None:
            try:
                _lock_fh.close()
            except OSError:
                pass
            _lock_fh = None
        return False


def запущен_админом() -> bool:
    if os.name != "nt":
        try:
            return os.geteuid() == 0
        except AttributeError:
            return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return True


def powershell_путь(x86: bool = False) -> str:
    if os.name != "nt":
        import shutil
        return shutil.which("pwsh") or shutil.which("powershell") or ""
    папка = системная_папка(x86=x86)
    if not папка:
        return ""
    p = os.path.join(папка, "WindowsPowerShell", "v1.0", "powershell.exe")
    return p if os.path.exists(p) else ""


# ---------------------------------------------------------------- форма data и подбор сертификата


def data_допустима(data) -> tuple:
    """Строка от Честного знака: печатные ASCII, 16..4000 знаков, без переводов строк,
    не начинается с «<», «{», «%PDF». Агент подписывает только такое: защита от подмены
    задания документом или скриптом, если мост вдруг скомпрометирован."""
    if not isinstance(data, str):
        return False, "data не строка"
    if not (DATA_MIN <= len(data) <= DATA_MAX):
        return False, "длина data %d вне 16..4000" % len(data)
    if any(ch in "\r\n" for ch in data):
        return False, "в data перевод строки"
    if any(not (0x20 <= ord(ch) <= 0x7E) for ch in data):
        return False, "в data непечатный или не-ASCII знак"
    s = data.lstrip()
    if s[:1] in ("<", "{") or s[:4] == "%PDF":
        return False, "data похожа на документ (%s), а не на строку Честного знака" % s[:4]
    return True, ""


def инн_цифры(inn) -> str:
    """ИНН организации: 10 цифр; 12 цифр с ведущими «00» (как в сертификатах ГОСТ) сводятся к 10."""
    d = "".join(ch for ch in str(inn or "") if ch.isdigit())
    if len(d) == 12 and d.startswith("00"):
        return d[2:]
    return d


def разобрать_subject(subject: str) -> dict:
    """Из строки субъекта сертификата берем только организацию и ИНН (без ФИО и должности).
    Понимает вид .NET/CAdESCOM: CN=..., O="ООО Ромашка", ИНН=007701004567, OID.1.2.643.100.4=7701004567."""
    поля, текущий, кавычки = [], [], False
    for ch in str(subject or ""):
        if ch == '"':
            кавычки = not кавычки
            continue
        if ch == "," and not кавычки:
            поля.append("".join(текущий))
            текущий = []
        else:
            текущий.append(ch)
    поля.append("".join(текущий))
    org, inn10, inn12 = "", "", ""
    for п in поля:
        if "=" not in п:
            continue
        k, v = п.split("=", 1)
        k, v = k.strip().upper(), v.strip()
        if k == "O":
            org = v
        elif k in ("OID.1.2.643.100.4", "1.2.643.100.4", "ИНН ЮЛ", "INNLE", "ИННЮЛ"):
            inn10 = "".join(ch for ch in v if ch.isdigit())
        elif k in ("OID.1.2.643.3.131.1.1", "1.2.643.3.131.1.1", "ИНН", "INN"):
            inn12 = "".join(ch for ch in v if ch.isdigit())
    inn = инн_цифры(inn10) or инн_цифры(inn12)
    return {"org": org, "inn": inn}


def сертификаты_для_заявки(список: list, закрепленные: list = None) -> list:
    """Описание сертификатов устройства для моста: отпечаток, организация, ИНН, срок.
    Ничего личного: ФИО и должность не передаются. Мост принимает не больше CERTS_MAX:
    сначала отпечатки из настроек (закрепленные), затем самые долгие по сроку."""
    out = []
    for c in список:
        out.append({"thumbprint": c.get("thumbprint", ""), "org": str(c.get("org") or "")[:200],
                    "inn": c.get("inn", ""), "not_after": c.get("not_after", "")})
    if len(out) > CERTS_MAX:
        нужные = set(закрепленные or [])
        остальные = sorted([c for c in out if c["thumbprint"] not in нужные], key=lambda c: c["not_after"] or "", reverse=True)
        out = [c for c in out if c["thumbprint"] in нужные] + остальные
        сказать("сертификатов на компьютере %d, в заявку идут первые %d (закрепленные в настройках и самые долгие по сроку)"
                % (len(out), CERTS_MAX))
        out = out[:CERTS_MAX]
    return out


def подобрать_сертификат(сертификаты: list, inn: str = "", thumbprint: str = "") -> tuple:
    """Сертификат для ключа. Отпечаток задан в настройках - только он (подпись по доверенности
    или выбор владельца); иначе действующий сертификат с ИНН организации ключа, самый долгий.
    Возвращает (сертификат или None, причина)."""
    действующие = [c for c in сертификаты if c.get("thumbprint")]
    if thumbprint:
        t = thumbprint.upper()
        for c in действующие:
            if c["thumbprint"].upper() == t:
                return c, ""
        return None, "сертификат с отпечатком %s из настроек не найден среди действующих" % хвост_отпечатка(t)
    inn = инн_цифры(inn)
    if not inn:
        return None, "у ключа нет ИНН организации, а отпечаток в настройках не задан"
    подходящие = [c for c in действующие if инн_цифры(c.get("inn")) == inn]
    if not подходящие:
        return None, "нет действующего сертификата с ИНН %s" % ("**" + inn[-4:])
    подходящие.sort(key=lambda c: c.get("not_after") or "", reverse=True)
    return подходящие[0], ""


def метка_сертификата(c: dict) -> str:
    inn = инн_цифры(c.get("inn"))
    return "%s, ИНН %s, до %s, отпечаток %s" % (
        c.get("org") or "(организация не указана)", ("**" + inn[-4:]) if inn else "нет",
        (c.get("not_after") or "")[:10], хвост_отпечатка(c.get("thumbprint", "")))


# ---------------------------------------------------------------- тела запросов и разбор ответов


def тело_регистрации(cfg: dict, сертификаты: list, csp_version: str = "") -> dict:
    return {
        "install_id": cfg["install_id"],
        "hostname": socket.gethostname()[:64],
        "os_label": ("%s %s %s" % (platform.system(), platform.release(), platform.version()))[:80].strip(),
        "agent_version": AGENT_VERSION,
        "csp_version": csp_version or "",
        "keys": [({"token": k["token"], "thumbprint": k["thumbprint"]} if k.get("thumbprint") else {"token": k["token"]}) for k in cfg["keys"][:KEYS_MAX]],
        "certs": сертификаты_для_заявки(сертификаты, [k["thumbprint"] for k in cfg["keys"] if k.get("thumbprint")]),
        "pin_prompt_seen": bool(cfg.get("pin_prompt_seen")),
    }


def тело_опроса(cfg: dict, force: bool = False, report: dict = None) -> dict:
    тело = {"install_id": cfg["install_id"], "agent_version": AGENT_VERSION}
    if force:
        тело["force"] = True
    if report:
        тело["report"] = {"key_tail": str(report.get("key_tail") or ""), "error_code": str(report.get("error_code") or "")[:64],
                          "error_text": str(report.get("error_text") or "")[:400],
                          "pin_prompt_seen": bool(report.get("pin_prompt_seen", cfg.get("pin_prompt_seen")))}
    return тело


def тело_подписи(cfg: dict, задание: dict, signature: str, thumbprint: str, inn: str = "") -> dict:
    return {"install_id": cfg["install_id"], "challenge_id": str(задание.get("challenge_id") or ""),
            "signature": signature, "thumbprint": thumbprint.upper(), "inn": inn or ""}


def тело_отвязки(cfg: dict, token_tail: str = "") -> dict:
    return {"install_id": cfg["install_id"], "token_tail": token_tail or ""}


def обработать_регистрацию(cfg: dict, код: int, ответ: dict) -> dict:
    """Итог регистрации: секрет установки (выдается один раз) кладется в настройки,
    пары ключ-сертификат пересказываются человеку. Возвращает {ok, status, pairs, poll_sec, error}."""
    if код == 200 and ответ.get("ok"):
        if ответ.get("agent_secret"):
            cfg["agent_secret"] = str(ответ["agent_secret"])
        if ответ.get("install_id"):
            cfg["install_id"] = str(ответ["install_id"])
        return {"ok": True, "status": ответ.get("status") or "pending", "pairs": ответ.get("pairs") or [],
                "poll_sec": int(ответ.get("poll_sec") or POLL_DEFAULT_SEC), "note": str(ответ.get("note") or ""),
                "min_agent_version": ответ.get("min_agent_version") or ""}
    detail = ответ.get("detail")
    if код == 422 and isinstance(detail, list):
        # Мост не повторяет тело в 422 (там были бы ключи): только поле и причина.
        поля = "; ".join("%s: %s" % (".".join(str(x) for x in (e.get("loc") or []) if x != "body"), e.get("msg") or "")
                        for e in detail if isinstance(e, dict))[:300]
        причина = поля or "неверные поля заявки"
    else:
        причина = str(ответ.get("reason") or ответ.get("error") or detail or "")[:200]
    текст = {
        400: "мост отверг заявку: " + (причина or "неверные данные"),
        401: "ключ в config.json не принят мостом: это не ключ «Маркировка» или он не существует",
        403: "мост не узнал этот компьютер: секрет установки не совпал или устройство отозвано. "
             "Агент попробует подать заявку заново; если не выйдет, удалите install_id и agent_secret из config.json и запустите снова",
        404: "install_id занят другим кабинетом: удалите install_id из config.json",
        413: "заявка слишком большая (много сертификатов)",
        422: "мост не принял поля заявки (%s): проверьте config.json, при 11 и более ключах или 31 и более сертификатах "
             "уменьшите их число" % причина,
        429: "лимит регистраций или устройств на ключ: подождите 10 минут или отзовите лишние компьютеры в кабинете",
    }.get(код, "мост ответил %s%s" % (код, (": " + причина) if причина else ""))
    return {"ok": False, "status": "error", "http": код, "error": текст, "reason": причина}


def обработать_опрос(код: int, ответ: dict) -> dict:
    """Нормализованный итог pull: action, задания, пауза до следующего опроса, причина словами."""
    if код == 429:
        return {"ok": False, "action": "wait", "reason": "too_fast", "text": REASON_RU["too_fast"],
                "next_poll_sec": max(POLL_MIN_SEC, int(ответ.get("next_poll_sec") or POLL_MIN_SEC)), "tasks": [], "keys": []}
    if код in (401, 403, 404):
        return {"ok": False, "action": "wait", "reason": "http_%d" % код,
                "text": {401: "ключ не принят мостом (выключен или не того вида)", 403: "компьютер не опознан: секрет не совпал или устройство отозвано",
                         404: "устройство не найдено: нужна новая регистрация"}[код],
                "next_poll_sec": BACKOFF_FORBIDDEN_SEC, "tasks": [], "keys": [], "http": код}
    if код != 200 or not isinstance(ответ, dict) or not ответ.get("ok"):
        return {"ok": False, "action": "wait", "reason": "http_%d" % код, "text": "мост ответил %s" % код,
                "next_poll_sec": POLL_DEFAULT_SEC, "tasks": [], "keys": [], "http": код}
    действие = str(ответ.get("action") or "idle")
    причина = str(ответ.get("reason") or "")
    задания = []
    for t in ответ.get("tasks") or []:
        if not isinstance(t, dict):
            continue
        задания.append({"key_tail": str(t.get("key_tail") or ""), "challenge_id": str(t.get("challenge_id") or ""),
                        "data": t.get("data"), "thumbprint": str(t.get("thumbprint") or "").upper(),
                        "expires_in_sec": int(t.get("expires_in_sec") or 300), "inn_required": bool(t.get("inn_required"))})
    return {"ok": True, "action": действие, "reason": причина, "text": REASON_RU.get(причина, причина),
            "next_poll_sec": max(POLL_MIN_SEC, int(ответ.get("next_poll_sec") or POLL_DEFAULT_SEC)),
            "tasks": задания, "keys": ответ.get("keys") or [],
            "min_agent_version": str(ответ.get("min_agent_version") or ""),
            "latest_agent_version": str(ответ.get("latest_agent_version") or "")}


def обработать_подпись(код: int, ответ: dict) -> dict:
    """Итог sign-in: успех с expires_at/next_renew_at, иначе причина и пауза (retry_after_sec)."""
    if код == 200 and ответ.get("ok"):
        return {"ok": True, "key_tail": str(ответ.get("key_tail") or ""), "expires_at": str(ответ.get("expires_at") or ""),
                "next_renew_at": str(ответ.get("next_renew_at") or ""), "inn_tail": str(ответ.get("inn_tail") or ""),
                "next_poll_sec": max(POLL_MIN_SEC, int(ответ.get("next_poll_sec") or POLL_DEFAULT_SEC))}
    причина = str(ответ.get("reason") or "")
    текст = {
        "marking_challenge_expired": "запрос подписи устарел или уже использован, жду следующий",
        "marking_cert_mismatch": "подписано не закрепленным сертификатом: мост в Честный знак подпись не отправил",
        "chz_rejected": "Честный знак отверг подпись",
        "marking_inn_mismatch": "ключ сессии принадлежит другой организации: ИНН сертификата не совпал с ИНН ключа",
        "marking_inn_required": "Честному знаку нужен ИНН организации: впишите ИНН в карточке ключа в кабинете",
    }.get(причина, str(ответ.get("error") or ответ.get("detail") or "мост ответил %s" % код)[:200])
    if код == 403:
        текст = "ключ выключен в кабинете"
    return {"ok": False, "reason": причина or ("http_%d" % код), "text": текст,
            "retry_after_sec": int(ответ.get("retry_after_sec") or 0), "http": код}


def версия_кортеж(v: str) -> tuple:
    out = []
    for ч in str(v or "").split("."):
        d = "".join(ch for ch in ч if ch.isdigit())
        out.append(int(d) if d else 0)
    return tuple(out + [0] * (3 - len(out)))


# ---------------------------------------------------------------- HTTP (только https, без редиректов)


class _БезРедиректа(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "редирект с секретными заголовками запрещен", headers, fp)


def tls_контекст() -> ssl.SSLContext:
    """Проверка сертификата моста только по системным корневым сертификатам Windows.
    ssl.create_default_context() после хранилищ Windows вызывает set_default_verify_paths(),
    а тот берет SSL_CERT_FILE и SSL_CERT_DIR из окружения (ключ -I их не отключает): так
    подложенный корневой сертификат открыл бы подмену моста. Здесь хранилища
    CA и ROOT читаются так же, как это делает сам Python, но без set_default_verify_paths().
    Не Windows - обычный контекст."""
    if os.name != "nt":
        return ssl.create_default_context()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    # По одному: если OpenSSL не разберет какой-то нестандартный сертификат из хранилища
    # (ssl.SSLError, ASN1), пропускается только он, а не все корни и не весь агент.
    загружено = пропущено = 0
    for хранилище in ("CA", "ROOT"):
        try:
            записи = ssl.enum_certificates(хранилище)
        except OSError:
            continue
        for cert, кодировка, доверие in записи:
            if кодировка == "x509_asn" and (доверие is True or ssl.Purpose.SERVER_AUTH.oid in доверие):
                try:
                    ctx.load_verify_locations(cadata=bytes(cert))
                    загружено += 1
                except (ssl.SSLError, ValueError):
                    пропущено += 1
    if пропущено or not загружено:
        журнал("TLS: корневых сертификатов Windows загружено %d, не разобрано %d" % (загружено, пропущено))
    return ctx


def прокси_обработчик() -> urllib.request.ProxyHandler:
    """Прокси на Windows - только из системных настроек (реестр, как у браузера), без
    HTTP_PROXY, HTTPS_PROXY и ALL_PROXY из окружения (run.cmd их тоже очищает). Своего
    прокси в config.json у агента нет. TLS проверяется и через прокси."""
    if os.name == "nt":
        try:
            прокси = urllib.request.getproxies_registry()
        except Exception:  # noqa: BLE001
            прокси = {}
        if not прокси and прокси_автонастройка():
            сказать("в Windows настроен сценарий автонастройки прокси (PAC), агент его не понимает: если прямого выхода "
                    "в интернет нет, впишите прокси вручную (Параметры Windows, Сеть и Интернет, Прокси-сервер, "
                    "«Использовать прокси-сервер»)")
        return urllib.request.ProxyHandler(прокси)
    return urllib.request.ProxyHandler()


def прокси_автонастройка() -> bool:
    """Задан ли AutoConfigURL (сценарий PAC) в настройках Интернета текущего пользователя."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings") as k:
            v, _ = winreg.QueryValueEx(k, "AutoConfigURL")
            return bool(str(v or "").strip())
    except Exception:  # noqa: BLE001
        return False


_opener = None


def _опенер():
    """Опенер собирается при первом запросе, а не при импорте: сбой TLS или прокси не мешает
    --certs и --setup до обращения к мосту."""
    global _opener
    if _opener is None:
        _opener = urllib.request.build_opener(_БезРедиректа, прокси_обработчик(), urllib.request.HTTPSHandler(context=tls_контекст()))
    return _opener


def запрос(base_url: str, путь: str, тело: dict, token: str, секрет: str = "", timeout: int = HTTP_TIMEOUT) -> tuple:
    """POST JSON с заголовками X-Bridge-Token и X-Agent-Secret. Возвращает (код, словарь);
    код 0 - нет связи. Тело ответа дальше 64 КБ не читается."""
    url = base_url.rstrip("/") + путь
    if not адрес_допустим(url):
        return 0, {"ok": False, "error": "адрес моста должен быть https"}
    data = json.dumps(тело, ensure_ascii=False).encode("utf-8")
    заголовки = {"Content-Type": "application/json", "X-Bridge-Token": token, "User-Agent": "odl-marking-agent/" + AGENT_VERSION}
    if секрет:
        заголовки["X-Agent-Secret"] = секрет
    req = urllib.request.Request(url, data=data, headers=заголовки, method="POST")
    try:
        with _опенер().open(req, timeout=timeout) as r:
            return r.status, _json_или_пусто(r.read(65536))
    except urllib.error.HTTPError as e:
        try:
            тело_ответа = e.read(65536)
        except Exception:  # noqa: BLE001
            тело_ответа = b""
        return e.code, _json_или_пусто(тело_ответа)
    except Exception as e:  # noqa: BLE001
        return 0, {"ok": False, "error": str(e)[:160]}


def _json_или_пусто(b: bytes) -> dict:
    """Словарь ответа. Отказы мост бросает как HTTPException с detail-словарем, и тело
    приходит в обертке {"detail": {"ok": false, "reason": ..., "retry_after_sec": ...}}:
    такой словарь разворачивается на верхний уровень, чтобы reason и паузы читались одинаково."""
    try:
        v = json.loads(b or b"{}")
    except ValueError:
        return {}
    if not isinstance(v, dict):
        return {}
    d = v.get("detail")
    if isinstance(d, dict):
        плоский = dict(v)
        плоский.update(d)
        return плоский
    return v


# ---------------------------------------------------------------- подпись: comtypes или PowerShell


class ОшибкаПодписи(Exception):
    def __init__(self, код: str, текст: str, hresult: int = 0):
        super().__init__(текст)
        self.код = код
        self.текст = текст
        self.hresult = hresult


def _hresult(e: Exception) -> int:
    for имя in ("hresult", "winerror"):
        v = getattr(e, имя, None)
        if isinstance(v, int):
            return v & 0xFFFFFFFF
    args = getattr(e, "args", ())
    if args and isinstance(args[0], int):
        return args[0] & 0xFFFFFFFF
    return 0


def код_ошибки_csp(e: Exception, текст: str = "") -> ОшибкаПодписи:
    """HRESULT или текст ошибки COM -> код для моста и фраза для человека."""
    hr = _hresult(e)
    t = (текст or str(e) or "").strip()
    if not hr:
        # PowerShell отдает код только в тексте: «Exception calling "SignCades" ... (0x8010006E)».
        m = re.search(r"0x([0-9A-Fa-f]{8})\b", t)
        if m:
            hr = int(m.group(1), 16)
    нижний = t.lower()
    if "ODL_PS_CLM" in t:
        return ОшибкаПодписи(ERR_CSP, ТЕКСТ_CLM, hr)
    if "ODL_CERT_NOT_FOUND" in t or "не найден в хранилище" in нижний:
        return ОшибкаПодписи(ERR_CERT_NOT_FOUND, "сертификат не найден в хранилище «Личное» текущего пользователя", hr)
    if "ODL_PLUGIN_MISSING" in t or hr in _HRESULT_PLUGIN or (
            "cadescom" in нижний and ("not registered" in нижний or "не зарегистрирован" in нижний or "80040154" in нижний)):
        return ОшибкаПодписи(ERR_PLUGIN_MISSING, "компоненты КриптоПро (CAdESCOM) не найдены: установите КриптоПро CSP и "
                                                  "«КриптоПро ЭЦП Browser plug-in» (https://www.cryptopro.ru/products/cades/plugin)", hr)
    if hr in _HRESULT_PIN or any(w in нижний for w in _HRESULT_PIN_WORDS):
        return ОшибкаПодписи(ERR_PIN_REQUIRED, "КриптоПро ждет пароль контейнера (окно ПИН-кода): сохраните пароль в КриптоПро, см. README", hr)
    return ОшибкаПодписи("%s:%08X" % (ERR_CSP, hr) if hr else ERR_CSP, ("ошибка КриптоПро: " + t[:200]) if t else "ошибка КриптоПро", hr)


ТЕКСТ_CLM = ("PowerShell ограничен политикой организации (режим ConstrainedLanguage: AppLocker, WDAC): подпись "
             "через PowerShell невозможна; нужен пакет comtypes в runtime или исключение для агента в политике")


def _comtypes():
    try:
        import comtypes.client  # noqa: F401
        return __import__("comtypes.client").client
    except Exception:  # noqa: BLE001
        return None


def список_сертификатов_com() -> list:
    """Действующие сертификаты с закрытым ключом из «Личное» через CAdESCOM.Store (comtypes)."""
    cc = _comtypes()
    if cc is None:
        raise ОшибкаПодписи(ERR_PLUGIN_MISSING, "comtypes недоступен")
    try:
        store = cc.CreateObject("CAdESCOM.Store")
    except Exception as e:  # noqa: BLE001
        raise код_ошибки_csp(e)
    out, сейчас = [], datetime.datetime.now()
    try:
        # COMError из Open, Certificates, Item, Thumbprint - тоже ОшибкаПодписи: тогда список
        # берется через PowerShell, а --certs и --setup не падают с трассировкой.
        store.Open(CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE, CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED)
        certs = store.Certificates
        for i in range(1, int(certs.Count) + 1):
            c = certs.Item(i)
            try:
                if not c.HasPrivateKey():
                    continue
            except Exception:  # noqa: BLE001
                pass
            try:
                до = c.ValidToDate
                до_dt = до if isinstance(до, datetime.datetime) else datetime.datetime.fromisoformat(str(до))
            except Exception:  # noqa: BLE001
                до_dt = None
            if до_dt is not None and до_dt.replace(tzinfo=None) < сейчас:
                continue
            алг = ""
            try:
                алг = str(c.PublicKey().Algorithm.Value)
            except Exception:  # noqa: BLE001
                алг = ""
            if алг and not алг.startswith("1.2.643"):
                continue
            разбор = разобрать_subject(str(c.SubjectName))
            out.append({"thumbprint": str(c.Thumbprint).upper(), "org": разбор["org"], "inn": разбор["inn"],
                        "not_after": (до_dt.strftime("%Y-%m-%dT%H:%M:%SZ") if до_dt else "")})
    except ОшибкаПодписи:
        raise
    except Exception as e:  # noqa: BLE001
        raise код_ошибки_csp(e)
    finally:
        try:
            store.Close()
        except Exception:  # noqa: BLE001
            pass
    return out


# Первым делом режим языка (в ConstrainedLanguage и [Console], и COM запрещены; ответ простой
# строкой), затем UTF-8 и без прогресса (он идет в stderr). Дата - в инвариантной культуре:
# двоеточие в формате .NET иначе заменяется разделителем времени из региональных настроек.
_PS_НАЧАЛО = ("if($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage'){'ODL_PS_CLM';exit 3};"
              "[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false);$ProgressPreference='SilentlyContinue';")
_PS_СПИСОК = (
    _PS_НАЧАЛО + "$ErrorActionPreference='Stop';"
    "try{$st=New-Object System.Security.Cryptography.X509Certificates.X509Store('My','CurrentUser');$st.Open('ReadOnly');"
    "foreach($c in $st.Certificates){if(-not $c.HasPrivateKey){continue};if($c.NotAfter -lt (Get-Date)){continue};"
    "$a='';try{$a=$c.PublicKey.Oid.Value}catch{};if($a -and -not $a.StartsWith('1.2.643')){continue};"
    "Write-Output ('ODL_CERT'+\"`t\"+$c.Thumbprint+\"`t\"+$c.NotAfter.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ',[Globalization.CultureInfo]::InvariantCulture)+\"`t\"+$c.Subject)};"
    "$st.Close();exit 0}catch{[Console]::Error.WriteLine($_.Exception.Message);exit 1}"
)


def разобрать_список_ps(вывод: str) -> list:
    out = []
    for строка in (вывод or "").splitlines():
        части = строка.strip().split("\t")
        if len(части) < 4 or части[0] != "ODL_CERT":
            continue
        разбор = разобрать_subject("\t".join(части[3:]))
        out.append({"thumbprint": части[1].strip().upper(), "org": разбор["org"], "inn": разбор["inn"], "not_after": части[2].strip()})
    return out


def _ps_запуск(скрипт: str, timeout: int, x86: bool = False) -> tuple:
    exe = powershell_путь(x86=x86)
    if not exe:
        raise ОшибкаПодписи(ERR_PLUGIN_MISSING, "штатный PowerShell не найден")
    encoded = base64.b64encode(скрипт.encode("utf-16le")).decode("ascii")
    try:
        r = subprocess.run([exe] + _PS_КЛЮЧИ + ["-EncodedCommand", encoded], stdin=subprocess.DEVNULL,
                           capture_output=True, timeout=timeout, env=окружение_ps(), cwd=системная_папка() or None)
    except subprocess.TimeoutExpired:
        raise ОшибкаПодписи(ERR_PIN_REQUIRED, "подпись не завершилась за %d с: скорее всего, КриптоПро ждет пароль контейнера" % timeout)
    except OSError as e:
        # Запуск powershell.exe запрещен (SRP, AppLocker: WinError 1260) или заблокирован антивирусом.
        raise ОшибкаПодписи(ERR_CSP, "PowerShell не запустился (%s): возможно, его запуск запрещен политикой организации "
                                     "или антивирусом" % str(e)[:120])
    return r.returncode, r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")


def список_сертификатов_ps() -> list:
    rc, out, err = _ps_запуск(_PS_СПИСОК, 60)
    if rc != 0:
        if "ODL_PS_CLM" in out:
            raise ОшибкаПодписи(ERR_CSP, ТЕКСТ_CLM)
        raise ОшибкаПодписи(ERR_CSP, "список сертификатов не получен: " + _ps_ошибка(err)[:200])
    return разобрать_список_ps(out)


def список_сертификатов() -> list:
    """Сначала comtypes (тот же COM, что в кабинете), иначе PowerShell."""
    if _comtypes() is not None:
        try:
            return список_сертификатов_com()
        except ОшибкаПодписи as e:
            журнал("сертификаты через COM не получены (%s), пробую PowerShell" % e.код)
    return список_сертификатов_ps()


def контент_base64(data: str) -> str:
    """Content для CadesSignedData при CADESCOM_BASE64_TO_BINARY: Base64 от UTF-8 строки,
    как btoa(unescape(encodeURIComponent(data))) в кабинете."""
    return base64.b64encode(data.encode("utf-8")).decode("ascii")


def подписать_com(thumbprint: str, data: str) -> str:
    cc = _comtypes()
    if cc is None:
        raise ОшибкаПодписи(ERR_PLUGIN_MISSING, "comtypes недоступен")
    try:
        store = cc.CreateObject("CAdESCOM.Store")
    except Exception as e:  # noqa: BLE001
        raise код_ошибки_csp(e)
    try:
        store.Open(CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE, CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED)
        found = store.Certificates.Find(CAPICOM_CERTIFICATE_FIND_SHA1_HASH, thumbprint)
        if int(found.Count) < 1:
            raise ОшибкаПодписи(ERR_CERT_NOT_FOUND, "сертификат не найден в хранилище")
        cert = found.Item(1)
        signer = cc.CreateObject("CAdESCOM.CPSigner")
        signer.Certificate = cert
        signer.CheckCertificate = True
        sd = cc.CreateObject("CAdESCOM.CadesSignedData")
        sd.ContentEncoding = CADESCOM_BASE64_TO_BINARY
        sd.Content = контент_base64(data)
        sig = sd.SignCades(signer, CADESCOM_CADES_BES, False)
        return "".join(str(sig).split())
    except ОшибкаПодписи:
        raise
    except Exception as e:  # noqa: BLE001
        raise код_ошибки_csp(e)
    finally:
        try:
            store.Close()
        except Exception:  # noqa: BLE001
            pass


def скрипт_подписи_ps(thumbprint: str, content_b64: str) -> str:
    """Те же COM-вызовы, что в markingSignData кабинета, но из PowerShell (без comtypes
    и для 32-разрядного CAdESCOM). Отпечаток и Base64 проверены, в скрипт попадают как есть."""
    if len(thumbprint) != 40 or any(ch not in "0123456789ABCDEF" for ch in thumbprint.upper()):
        raise ОшибкаПодписи(ERR_CERT_NOT_FOUND, "отпечаток из задания неверной формы")
    if any(ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" for ch in content_b64):
        raise ОшибкаПодписи(ERR_CSP, "содержимое для подписи не Base64")
    # ODL_PLUGIN_MISSING только для «класс не зарегистрирован» (0x80040154, 0x800401F3, 0x80080005):
    # прочие сбои (отказ доступа и т.п.) идут как есть и не уводят на 32-разрядный PowerShell.
    return _PS_НАЧАЛО + (
        "$ErrorActionPreference='Stop';try{"
        "try{$store=New-Object -ComObject 'CAdESCOM.Store'}catch{"
        "if(($_.Exception.HResult -in @(-2147221164,-2147221005,-2146959355)) -or ([string]$_.Exception.Message -match '80040154|800401F3|80080005'))"
        "{throw 'ODL_PLUGIN_MISSING'};throw};"
        "$store.Open(%d,'%s',%d);"
        "$found=$store.Certificates.Find(%d,'%s');"
        "if($found.Count -lt 1){throw 'ODL_CERT_NOT_FOUND'};"
        "$cert=$found.Item(1);"
        "$signer=New-Object -ComObject 'CAdESCOM.CPSigner';"
        "$signer.Certificate=$cert;$signer.CheckCertificate=$true;"
        "$sd=New-Object -ComObject 'CAdESCOM.CadesSignedData';"
        "$sd.ContentEncoding=%d;$sd.Content='%s';"
        "$sig=$sd.SignCades($signer,%d,$false);"
        "$store.Close();"
        "Write-Output ('ODL_SIG:'+(($sig -replace \"`r\",'') -replace \"`n\",''));exit 0"
        "}catch{[Console]::Error.WriteLine($_.Exception.Message);exit 1}"
    ) % (CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE, CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED,
         CAPICOM_CERTIFICATE_FIND_SHA1_HASH, thumbprint.upper(), CADESCOM_BASE64_TO_BINARY, content_b64, CADESCOM_CADES_BES)


def подписать_ps(thumbprint: str, data: str, x86: bool = False) -> str:
    rc, out, err = _ps_запуск(скрипт_подписи_ps(thumbprint, контент_base64(data)), SIGN_TIMEOUT_SEC, x86=x86)
    for строка in out.splitlines():
        if строка.startswith("ODL_SIG:"):
            return строка[len("ODL_SIG:"):].strip()
    # Маркеры ищутся во всем выводе, человеку - последние строки stderr без CLIXML.
    маркеры = " ".join(m for m in ("ODL_PS_CLM", "ODL_PLUGIN_MISSING", "ODL_CERT_NOT_FOUND") if m in out or m in err)
    текст = (маркеры + " " + _ps_ошибка(err)).strip()[:300] or ("PowerShell rc=%s" % rc)
    raise код_ошибки_csp(Exception(текст), текст)


def _ps_ошибка(err: str) -> str:
    """Последние три строки stderr PowerShell без строк CLIXML."""
    строки = [s.strip() for s in (err or "").splitlines() if s.strip() and not s.lstrip().startswith(("#< CLIXML", "<Objs"))]
    return " ".join(строки[-3:])


_БЭКЕНД = {"имя": ""}   # comtypes | ps | ps32, выясняется один раз


def подписать(thumbprint: str, data: str, интерактивно: bool = False) -> str:
    """Подпись CAdES-BES присоединенная, Base64. Разрядность: comtypes в 64-разрядном Python
    не найдет 32-разрядный CAdESCOM, тогда подпись идет через 32-разрядный PowerShell.

    comtypes подписывает внутри процесса Python, и окно пароля контейнера без человека у
    компьютера держало бы вызов вечно (агент встал бы вместе с замком). Поэтому comtypes
    только при настройке (интерактивно=True, человек рядом), а в рабочем цикле - PowerShell,
    который через SIGN_TIMEOUT_SEC снимается и дает pin_required. Исключение - PowerShell в
    режиме ConstrainedLanguage: другого пути нет, тогда и в цикле comtypes."""
    ок, причина = data_допустима(data)
    if not ок:
        raise ОшибкаПодписи("data_rejected", причина)
    if (интерактивно or _БЭКЕНД["имя"] == "comtypes") and _БЭКЕНД["имя"] in ("", "comtypes") and _comtypes() is not None:
        try:
            sig = подписать_com(thumbprint, data)
            _БЭКЕНД["имя"] = "comtypes"
            return sig
        except ОшибкаПодписи as e:
            if e.код != ERR_PLUGIN_MISSING or _БЭКЕНД["имя"] == "comtypes":
                raise
            журнал("CAdESCOM через comtypes недоступен (разрядность или нет comtypes), переход на PowerShell")
    if _БЭКЕНД["имя"] in ("", "comtypes", "ps"):
        try:
            sig = подписать_ps(thumbprint, data)
            _БЭКЕНД["имя"] = "ps"
            return sig
        except ОшибкаПодписи as e:
            if e.текст == ТЕКСТ_CLM and not интерактивно and _comtypes() is not None:
                журнал("PowerShell в режиме ConstrainedLanguage, подпись через comtypes (без ограничения по времени)")
                sig = подписать_com(thumbprint, data)
                _БЭКЕНД["имя"] = "comtypes"
                return sig
            if e.код != ERR_PLUGIN_MISSING or _БЭКЕНД["имя"] == "ps" or not powershell_путь(x86=True):
                raise
            журнал("CAdESCOM не найден в 64-разрядном PowerShell, пробую 32-разрядный (SysWOW64)")
    sig = подписать_ps(thumbprint, data, x86=True)
    _БЭКЕНД["имя"] = "ps32"
    return sig


def версия_csp() -> str:
    if os.name != "nt":
        return ""
    try:
        import winreg
        for ключ in (r"SOFTWARE\Crypto Pro\Cryptography\CurrentVersion", r"SOFTWARE\WOW6432Node\Crypto Pro\Cryptography\CurrentVersion"):
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, ключ) as k:
                    v, _ = winreg.QueryValueEx(k, "Version")
                    return str(v)[:32]
            except OSError:
                continue
    except Exception:  # noqa: BLE001
        return ""
    return ""


# ---------------------------------------------------------------- агент


class Агент:
    def __init__(self, cfg: dict, сертификаты_fn=None, подписать_fn=None, запрос_fn=None, спать_fn=None, часы_fn=None):
        self.cfg = cfg
        self.сертификаты_fn = сертификаты_fn or список_сертификатов
        self.подписать_fn = подписать_fn or подписать
        self.запрос_fn = запрос_fn or запрос
        self.спать = спать_fn or time.sleep
        self.часы = часы_fn or time.monotonic
        self.состояние = состояние_прочитать()
        self.сертификаты = []
        self.сертификаты_при_заявке = None
        self.отказов_доступа = 0
        self.отчет = None
        self.пауза_сети = POLL_MIN_SEC
        self.без_связи_с = None
        self.истекших_подряд = 0
        self.подписей = 0
        self.остановлен = False

    # --- транспорт
    def _ключ_заголовка(self) -> str:
        i = int(self.состояние.get("key_index") or 0)
        ключи = self.cfg["keys"]
        return ключи[i % len(ключи)]["token"]

    def _следующий_ключ(self) -> None:
        """Первый ключ выключен (401) - заголовок берет следующий ключ из списка."""
        self.состояние["key_index"] = (int(self.состояние.get("key_index") or 0) + 1) % max(1, len(self.cfg["keys"]))
        состояние_записать(self.состояние)

    def post(self, путь: str, тело: dict) -> tuple:
        return self.запрос_fn(self.cfg["base_url"], путь, тело, self._ключ_заголовка(), self.cfg.get("agent_secret", ""))

    # --- регистрация
    def зарегистрировать(self) -> dict:
        if not self.cfg.get("install_id"):
            self.cfg["install_id"] = "mka-" + secrets.token_hex(8)
        try:
            self.сертификаты = self.сертификаты_fn()
        except ОшибкаПодписи as e:
            сказать("сертификаты не прочитаны: %s" % e.текст)
            self.сертификаты = []
        if not self.сертификаты:
            сказать("на этом компьютере нет действующих сертификатов с закрытым ключом: заявка уйдет без сертификата")
        код, ответ = self.post("/api/v1/marking/agent/register", тело_регистрации(self.cfg, self.сертификаты, версия_csp()))
        if код == 403 and self.cfg.get("agent_secret"):
            # Устройство отозвано в кабинете (секрет на мосте затерт) или секрет не совпал:
            # заявка заново без секрета (мост выдаст новый), как у первого запуска.
            сказать("мост не принял секрет установки (устройство отозвано?): подаю заявку заново")
            self.cfg["agent_secret"] = ""
            код, ответ = self.post("/api/v1/marking/agent/register", тело_регистрации(self.cfg, self.сертификаты, версия_csp()))
        итог = обработать_регистрацию(self.cfg, код, ответ)
        if итог["ok"]:
            self.состояние["registered_at"] = self.часы()
            self.состояние.pop("need_register", None)
            self.сертификаты_при_заявке = sorted(c.get("thumbprint", "") for c in self.сертификаты)
            состояние_записать(self.состояние)
            try:
                сохранить_настройки(self.cfg)
            except ОшибкаНастроек as e:
                # Секрет установки не записан: при следующем запуске агент подаст заявку заново.
                сказать("настройки не сохранены: %s" % e)
                итог["ok"] = False
                return итог
            сказать("регистрация: %s, компьютер %s" % ({"pending": "ждет подтверждения в кабинете", "approved": "подтверждена"}.get(итог["status"], итог["status"]),
                                                       self.cfg["install_id"]))
            for п in итог["pairs"]:
                сказать("  ключ %s: %s, сертификат %s%s" % (п.get("key_tail"), п.get("status"), п.get("cert_label") or "не подобран",
                                                              ("; " + п["note"]) if п.get("note") else ""))
            if итог.get("note"):
                сказать("  " + итог["note"], в_журнал=False)
        else:
            if код == 401 and len(self.cfg["keys"]) > 1:
                self._следующий_ключ()
            сказать("регистрация не удалась: %s" % итог["error"])
        return итог

    # --- подпись одного задания
    def выполнить_задание(self, з: dict) -> dict:
        ключ = з["key_tail"]
        if self.состояние.get("signed", {}).get(ключ) == з["challenge_id"]:
            сказать("ключ %s: запрос %s уже подписан, повтор пропущен" % (ключ, з["challenge_id"][:8]))
            return {"ok": False, "reason": "duplicate"}
        ок, причина = data_допустима(з.get("data"))
        if not ок:
            сказать("ключ %s: задание отклонено, %s" % (ключ, причина))
            self.отчет = {"key_tail": ключ, "error_code": "data_rejected", "error_text": причина}
            return {"ok": False, "reason": "data_rejected"}
        if len(з["thumbprint"]) != 40:
            self.отчет = {"key_tail": ключ, "error_code": ERR_CERT_NOT_FOUND, "error_text": "в задании нет отпечатка"}
            return {"ok": False, "reason": ERR_CERT_NOT_FOUND}
        сказать("ключ %s: подписываю сертификатом %s (если появится окно КриптоПро, введите пароль контейнера)" % (ключ, хвост_отпечатка(з["thumbprint"])))
        начало = time.monotonic()
        try:
            sig = self.подписать_fn(з["thumbprint"], з["data"])
        except ОшибкаПодписи as e:
            сказать("ключ %s: подпись не выполнена (%s): %s" % (ключ, e.код, e.текст))
            self.отчет = {"key_tail": ключ, "error_code": e.код, "error_text": e.текст,
                          "pin_prompt_seen": bool(self.cfg.get("pin_prompt_seen")) or e.код == ERR_PIN_REQUIRED}
            if e.код == ERR_PIN_REQUIRED:
                self.cfg["pin_prompt_seen"] = True
            return {"ok": False, "reason": e.код}
        длит = time.monotonic() - начало
        if len(sig) > SIGNATURE_MAX:
            self.отчет = {"key_tail": ключ, "error_code": ERR_CSP, "error_text": "подпись длиннее %d" % SIGNATURE_MAX}
            return {"ok": False, "reason": "signature_too_long"}
        код, ответ = self.post("/api/v1/marking/agent/sign-in", тело_подписи(self.cfg, з, sig, з["thumbprint"]))
        sig = ""
        итог = обработать_подпись(код, ответ)
        if итог["ok"]:
            self.состояние.setdefault("signed", {})[ключ] = з["challenge_id"]
            self.состояние["last_sign_at"] = datetime.datetime.now().isoformat(timespec="seconds")
            состояние_записать(self.состояние)
            self.истекших_подряд = 0
            self.подписей += 1
            сказать("ключ %s: ключ сессии продлен до %s, следующее продление около %s (подпись %.1f с)" % (
                ключ, итог["expires_at"] or "?", итог["next_renew_at"] or "?", длит))
        else:
            if итог["reason"] == "marking_challenge_expired":
                self.истекших_подряд += 1
            сказать("ключ %s: мост не принял подпись (%s): %s%s" % (ключ, итог["reason"], итог["text"],
                                                                     (", пауза %d с" % итог["retry_after_sec"]) if итог["retry_after_sec"] else ""))
        return итог

    # --- один шаг главного цикла: возвращает паузу до следующего
    def шаг(self, force: bool = False) -> int:
        код, ответ = self.post("/api/v1/marking/agent/pull", тело_опроса(self.cfg, force, self.отчет))
        if код == 0:
            if self.без_связи_с is None:
                self.без_связи_с = self.часы()
            self.пауза_сети = min(BACKOFF_MAX_SEC, max(POLL_MIN_SEC, self.пауза_сети * 2))
            давно = self.часы() - self.без_связи_с
            сказать("нет связи с мостом (%s), повтор через %d с%s" % (ответ.get("error", "?"), self.пауза_сети,
                                                                        "; без связи уже больше 30 минут" if давно > NO_LINK_WARN_SEC else ""))
            return self.пауза_сети
        self.без_связи_с = None
        self.пауза_сети = POLL_MIN_SEC
        итог = обработать_опрос(код, ответ)
        if код == 200:
            self.отчет = None
        if код == 401 and len(self.cfg["keys"]) > 1:
            self._следующий_ключ()
        if not итог["ok"]:
            сказать("опрос: %s, повтор через %d с" % (итог["text"], итог["next_poll_sec"]))
            if итог.get("http") in (403, 404):
                # Следующая итерация цикла перерегистрируется (устройство отозвано или удалено
                # во «Входящих»): без этого агент стучался бы в 403 до перезапуска. Первый раз -
                # сразу, повторные отказы - с паузой 10 минут.
                self.состояние["need_register"] = True
                состояние_записать(self.состояние)
                self.отказов_доступа += 1
                return POLL_MIN_SEC if self.отказов_доступа == 1 else итог["next_poll_sec"]
            return итог["next_poll_sec"]
        self.отказов_доступа = 0
        мин = итог.get("min_agent_version")
        if мин and версия_кортеж(AGENT_VERSION) < версия_кортеж(мин):
            сказать("версия агента %s ниже минимальной %s: %s" % (AGENT_VERSION, мин, REASON_RU["version_too_old"]))
            return max(итог["next_poll_sec"], 300)
        новая = итог.get("latest_agent_version")
        if новая and версия_кортеж(новая) > версия_кортеж(AGENT_VERSION) and self.состояние.get("update_hint_day") != datetime.date.today().isoformat():
            self.состояние["update_hint_day"] = datetime.date.today().isoformat()
            состояние_записать(self.состояние)
            сказать("доступна новая версия агента %s (эта %s): скачайте в кабинете, когда удобно" % (новая, AGENT_VERSION))
        if итог["action"] == "sign":
            # Пауза после подписи: ответ sign-in свежее ответа pull (у него уже живой ключ сессии);
            # при нескольких ключах берем меньшую из удачных, отказ ЧЗ с retry_after_sec удлиняет.
            пауза, удачные = итог["next_poll_sec"], []
            for з in итог["tasks"]:
                р = self.выполнить_задание(з)
                if р.get("ok") and р.get("next_poll_sec"):
                    удачные.append(р["next_poll_sec"])
                elif р.get("retry_after_sec"):
                    пауза = max(пауза, р["retry_after_sec"])
                if р.get("reason") == ERR_CERT_NOT_FOUND:
                    # Закрепленного сертификата на компьютере больше нет (обновили): новая заявка
                    # со свежим списком сертификатов, чтобы владелец подтвердил новый во «Входящих».
                    self.состояние["need_register"] = True
                    состояние_записать(self.состояние)
            if удачные:
                пауза = max(пауза, min(удачные)) if пауза > итог["next_poll_sec"] else min(удачные)
            if self.истекших_подряд >= 3:
                сказать("три запроса подряд устарели (компьютер засыпал?): пауза 10 минут")
                self.истекших_подряд = 0
                return BACKOFF_MAX_SEC
            return max(POLL_MIN_SEC, пауза)
        if итог["action"] == "wait":
            сказать("ожидание: %s (опрос через %d с)" % (итог["text"] or итог["reason"], итог["next_poll_sec"]))
            return итог["next_poll_sec"]
        строки = []
        for k in итог["keys"]:
            строки.append("%s до %s" % (k.get("key_tail"), (k.get("session_until") or "?")[:16]))
        сказать("работает: ключи сессии живы (%s), опрос через %d с" % ("; ".join(строки) or "нет сведений", итог["next_poll_sec"]), в_журнал=False)
        return итог["next_poll_sec"]

    def пора_перерегистрироваться(self) -> bool:
        """Регистрация при каждом старте (новые ключи из config.json и смена сертификата доходят
        до моста только через register), после 403/404 (need_register), раз в сутки и когда
        список сертификатов на компьютере изменился."""
        if self.состояние.get("need_register"):
            return True
        было = self.состояние.get("registered_at")
        if not isinstance(было, (int, float)) or self.часы() - было >= REREGISTER_SEC:
            return True
        if self.сертификаты_при_заявке is not None:
            try:
                сейчас = sorted(c.get("thumbprint", "") for c in self.сертификаты_fn())
            except ОшибкаПодписи:
                return False
            return сейчас != self.сертификаты_при_заявке
        return False

    def цикл(self, force_first: bool = False) -> None:
        итог = self.зарегистрировать()
        if not итог["ok"] and итог.get("http") in (401, 404, 400) and not self.cfg.get("agent_secret"):
            сказать("исправьте config.json и запустите снова")
            return
        force = force_first
        проверка_сертификатов = self.часы()
        while not self.остановлен:
            try:
                if self.состояние.get("need_register") or (self.часы() - проверка_сертификатов >= 3600 and self.пора_перерегистрироваться()):
                    проверка_сертификатов = self.часы()
                    self.зарегистрировать()
                elif self.часы() - проверка_сертификатов >= 3600:
                    проверка_сертификатов = self.часы()
                пауза = self.шаг(force=force)
            except Exception as e:  # noqa: BLE001
                журнал("сбой шага: %s" % str(e)[:200])
                сказать("внутренняя ошибка, подробности в logs\\agent.log; повтор через 60 с")
                пауза = POLL_DEFAULT_SEC
            force = False
            if self.cfg.get("pin_prompt_seen") and not _чит(CONFIG).get("pin_prompt_seen"):
                try:
                    сохранить_настройки(self.cfg)
                except ОшибкаНастроек as e:
                    сказать("настройки не сохранены: %s" % e)
            начало = self.часы()
            while not self.остановлен and self.часы() - начало < пауза:
                self.спать(min(5, max(0.1, пауза - (self.часы() - начало))))

    def отвязать(self) -> bool:
        код, ответ = self.post("/api/v1/marking/agent/disconnect", тело_отвязки(self.cfg))
        if код == 200 and ответ.get("ok"):
            сказать("компьютер отвязан от кабинета: заявка и секрет установки на мосте удалены")
            self.cfg["agent_secret"] = ""
            self.cfg["install_id"] = ""
            try:
                сохранить_настройки(self.cfg)
            except ОшибкаНастроек as e:
                сказать("настройки не сохранены: %s; удалите install_id и agent_secret из config.json вручную" % e)
            return True
        сказать("отвязать не удалось: мост ответил %s %s" % (код, str(ответ.get("reason") or ответ.get("error") or "")[:120]))
        return False


# ---------------------------------------------------------------- первая настройка и команды


def показать_сертификаты(сертификаты: list) -> None:
    if not сертификаты:
        print("  действующих сертификатов с закрытым ключом не найдено")
        return
    for i, c in enumerate(сертификаты, 1):
        print("  %d. %s" % (i, метка_сертификата(c)))


def первая_настройка(cfg: dict, сертификаты_fn=None, подписать_fn=None, спросить=input) -> dict:
    """Настройка: сертификаты устройства, подбор по ИНН не делается здесь (ИНН ключа знает мост),
    двойная тестовая подпись каждым подобранным сертификатом, чтобы понять, спрашивает ли
    КриптоПро пароль при каждой подписи."""
    сертификаты = (сертификаты_fn or список_сертификатов)()
    print("Сертификаты организации на этом компьютере (хранилище «Личное», с закрытым ключом):")
    показать_сертификаты(сертификаты)
    if not сертификаты:
        print("Без сертификата агент подписывать не может. Установите сертификат организации и повторите.")
        return cfg
    кандидаты = {}
    for k in cfg["keys"]:
        if k.get("thumbprint"):
            c, причина = подобрать_сертификат(сертификаты, thumbprint=k["thumbprint"])
            if c:
                кандидаты[c["thumbprint"]] = c
            else:
                print("ключ %s: %s" % (хвост(k["token"]), причина))
    if not кандидаты:
        кандидаты = {c["thumbprint"]: c for c in сертификаты}
    print("\nПробная подпись (дважды, чтобы увидеть, спросит ли КриптоПро пароль во второй раз).")
    print("Если появится окно пароля контейнера, введите пароль и поставьте флажок «Сохранить пароль в системе».")
    пин = False
    for c in кандидаты.values():
        данные = "ODL-TEST-" + secrets.token_hex(12)
        длит = []
        for n in (1, 2):
            t0 = time.monotonic()
            try:
                if подписать_fn:
                    подписать_fn(c["thumbprint"], данные)
                else:
                    подписать(c["thumbprint"], данные, интерактивно=True)
                длит.append(time.monotonic() - t0)
                print("  %s: подпись %d прошла за %.1f с" % (хвост_отпечатка(c["thumbprint"]), n, длит[-1]))
            except ОшибкаПодписи as e:
                print("  %s: подпись %d не выполнена (%s): %s" % (хвост_отпечатка(c["thumbprint"]), n, e.код, e.текст))
                if e.код == ERR_PIN_REQUIRED:
                    пин = True
                break
        if len(длит) == 2 and длит[1] > PIN_SLOW_SEC:
            пин = True
    ответ = (спросить("Появлялось ли окно пароля при ВТОРОЙ подписи? (д/н, Enter = %s): " % ("д" if пин else "н")) or "").strip().lower()
    if ответ:
        пин = ответ[:1] in ("д", "y", "1")
    cfg["pin_prompt_seen"] = пин
    cfg["cert_confirmed_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    if пин:
        print("КриптоПро спрашивает пароль при каждой подписи. Без человека у компьютера продление не пройдет.")
        print("Сохраните пароль контейнера (README, раздел «Пароль контейнера») и повторите настройку.")
    else:
        print("Пароль не запрашивается: агент сможет продлевать ключ без участия человека.")
    сохранить_настройки(cfg)
    return cfg


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Агент Честного знака («Жёлтый мост»)")
    p.add_argument("--setup", action="store_true", help="первая настройка: сертификаты, пробная подпись, регистрация")
    p.add_argument("--certs", action="store_true", help="показать сертификаты устройства и выйти")
    p.add_argument("--sign-now", action="store_true", help="сразу запросить подпись (force) и продолжить работу")
    p.add_argument("--disconnect", action="store_true", help="отвязать компьютер от кабинета и выйти")
    p.add_argument("--once", action="store_true", help="один опрос и выход (для проверки)")
    a = p.parse_args(argv)
    dll_без_текущей_папки()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass
    print("Агент Честного знака («Жёлтый мост») %s, Python %s, %s-разрядный" % (
        AGENT_VERSION, platform.python_version(), "64" if sys.maxsize > 2 ** 32 else "32"))
    if not интерпретатор_допустим():
        print("Python запущен из папки агента, но это не runtime\\python.exe: %s" % sys.executable)
        print("Такой файл мог подложить кто-то другой. Запускайте агент через run.cmd; лишний python.exe удалите. Запуск отменен.")
        return 2
    if запущен_админом():
        print("Запущено от администратора. Запустите агент от обычной учетной записи, под которой установлен сертификат.")
        return 2
    if a.certs:
        try:
            показать_сертификаты(список_сертификатов())
        except ОшибкаПодписи as e:
            print("сертификаты не прочитаны: %s" % e.текст)
            return 1
        return 0
    try:
        cfg = загрузить_настройки()
    except ОшибкаНастроек as e:
        print("Настройки: %s" % e)
        return 2
    if not защитить_окружение():
        print("Права на папку агента не годятся: корень папки, run.cmd или agent.py может менять кто-то другой, либо")
        print("на config, logs, runtime (со всем содержимым) не удалось оставить права только вашей учетной записи.")
        if ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ["причина"]:
            print("%s: %s" % (ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ["путь"], ПОСЛЕДНИЙ_ОТКАЗ_ПРАВ["причина"]))
        print("Подробности в logs\\agent.log. Папка агента должна лежать на локальном диске, быть создана под вашей")
        print("учетной записью (вы ее владелец) и не быть сетевой. Запуск отменен.")
        return 2
    if not взять_замок():
        print("Агент уже запущен в этой папке (runtime\\agent.lock). Второй экземпляр не нужен.")
        return 3
    агент = Агент(cfg)
    if a.disconnect:
        return 0 if агент.отвязать() else 1
    if a.setup:
        try:
            cfg = первая_настройка(cfg)
        except ОшибкаПодписи as e:
            print("настройка прервана: %s" % e.текст)
            return 1
        except ОшибкаНастроек as e:
            print("настройка прервана: %s" % e)
            return 2
        агент.cfg = cfg
        итог = агент.зарегистрировать()
        if итог["ok"]:
            print("\nТеперь откройте кабинет onecdatalink.ru, вкладку «Входящие», и подтвердите заявку этого компьютера.")
            print("После подтверждения запустите run.cmd (или дождитесь запуска по задаче планировщика).")
        return 0 if итог["ok"] else 1
    журнал("старт агента %s, install %s, ключей %d" % (AGENT_VERSION, cfg.get("install_id") or "нет", len(cfg["keys"])))
    if a.once:
        агент.зарегистрировать()
        агент.шаг(force=a.sign_now)
        return 0
    try:
        агент.цикл(force_first=a.sign_now)
    except KeyboardInterrupt:
        сказать("остановлен пользователем")
    return 0


if __name__ == "__main__":
    sys.exit(main())
